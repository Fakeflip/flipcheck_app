const path = require("path");
const fs = require("fs");
const http = require("http");
const https = require("https");
const { spawn } = require("child_process");
const keytar = require("keytar");
const os = require("os");
const crypto = require("crypto");
const { app, BrowserWindow, ipcMain, shell } = require("electron");
const { loadSettings, saveSettings } = require("./settingsStore.js");

// ─── Auto-Updater (electron-updater) ─────────────────────────────────────────
let autoUpdater = null;
try {
  autoUpdater = require("electron-updater").autoUpdater;
  const log   = require("electron-log");
  autoUpdater.logger          = log;
  autoUpdater.autoDownload    = true;
  autoUpdater.autoInstallOnAppQuit = true;
} catch {}

// ─── Paths ───────────────────────────────────────────────────────────────────
const APP_HTML = path.join(__dirname, "index.html");
const IS_PROD = app.isPackaged;

// ─── Env ──────────────────────────────────────────────────────────────────────
try {
  const prodEnv = path.join(process.resourcesPath, ".env");
  require("dotenv").config({ path: fs.existsSync(prodEnv) ? prodEnv : undefined });
} catch {}

const MODE = IS_PROD ? "remote" : (process.env.FLIPCHECK_MODE || "local").toLowerCase();
const REMOTE_BASE = (process.env.FLIPCHECK_BACKEND_BASE || "https://api.joinflipcheck.app").replace(/\/+$/, "");
const AUTH_URL = process.env.FLIPCHECK_AUTH_URL || "https://gate.joinflipcheck.app/auth/discord/login";
const APP_VERSION = process.env.FLIPCHECK_VERSION || app.getVersion() || "2.0.0";
const HOST = "127.0.0.1";
const PORT_FROM = 9000;
const PORT_TO = 9010;

let mainWindow = null;
let backendProc = null;
let BACKEND_PORT = null;

// ─── Keytar ──────────────────────────────────────────────────────────────────
const SVC = "flipcheck";
const ACC = "gate_token";
const getToken = () => keytar.getPassword(SVC, ACC).catch(() => null);
const saveToken = (t) => keytar.setPassword(SVC, ACC, t).catch(() => {});
const deleteToken = () => keytar.deletePassword(SVC, ACC).catch(() => {});

// ─── Inventory Store ─────────────────────────────────────────────────────────
function invPath() {
  return path.join(app.getPath("userData"), "inventory.json");
}

function readInv() {
  try {
    const p = invPath();
    if (!fs.existsSync(p)) return { version: 1, items: [] };
    const json = JSON.parse(fs.readFileSync(p, "utf8") || "{}");
    if (!Array.isArray(json?.items)) json.items = [];
    return json;
  } catch {
    return { version: 1, items: [] };
  }
}

function writeInv(state) {
  try {
    fs.writeFileSync(invPath(), JSON.stringify(state, null, 2), "utf8");
    return true;
  } catch {
    return false;
  }
}

function uid() { return crypto.randomBytes(10).toString("hex"); }
function nowIso() { return new Date().toISOString(); }

function normalizeItem(input) {
  const it = { ...(input || {}) };
  if (!it.id) it.id = uid();
  if (!it.created_at) it.created_at = nowIso();
  it.updated_at = nowIso();
  it.market = it.market || "ebay";
  it.status = it.status || "IN_STOCK";
  it.title = it.title || "";
  it.ean = it.ean || "";
  it.sku = it.sku || it.ean || "";
  it.qty = Number.isFinite(Number(it.qty)) ? Number(it.qty) : 1;
  it.ek = it.ek !== undefined ? Number(it.ek) || null : null;
  it.sell_price = it.sell_price !== undefined ? Number(it.sell_price) || null : null;
  it.sold_at = it.sold_at || null;
  it.label = it.label || "";
  it.notes = it.notes || "";
  return it;
}

// ─── Price History Store ──────────────────────────────────────────────────────
function histPath() {
  return path.join(app.getPath("userData"), "price_history.json");
}

function readHist() {
  try {
    const p = histPath();
    if (!fs.existsSync(p)) return {};
    return JSON.parse(fs.readFileSync(p, "utf8") || "{}") || {};
  } catch {
    return {};
  }
}

function writeHist(data) {
  try {
    fs.writeFileSync(histPath(), JSON.stringify(data, null, 2), "utf8");
    return true;
  } catch {
    return false;
  }
}

// ─── Network helpers ──────────────────────────────────────────────────────────
function httpGet(url, timeoutMs = 1500) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith("https://") ? https : http;
    const req = lib.get(url, (res) => { res.resume(); resolve(res.statusCode || 0); });
    req.on("error", reject);
    req.setTimeout(timeoutMs, () => req.destroy(new Error("timeout")));
  });
}

async function waitForHttp(url, timeoutMs = 15000) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    try { if ((await httpGet(url, 1200)) > 0) return true; } catch {}
    await new Promise(r => setTimeout(r, 300));
  }
  return false;
}

async function isPortFree(port) {
  return new Promise((resolve) => {
    const srv = http.createServer();
    srv.once("error", () => resolve(false));
    srv.once("listening", () => srv.close(() => resolve(true)));
    srv.listen(port, HOST);
  });
}

async function pickFreePort(from, to) {
  for (let p = from; p <= to; p++) {
    if (await isPortFree(p)) return p;
  }
  return null;
}

function apiBase() {
  if (MODE === "remote") return REMOTE_BASE;
  return `http://${HOST}:${BACKEND_PORT}`;
}

// ─── Scanner Server (Handy-Barcode) ──────────────────────────────────────────
function getLocalIP() {
  for (const iface of Object.values(os.networkInterfaces()).flat()) {
    if (iface && iface.family === "IPv4" && !iface.internal) return iface.address;
  }
  return "127.0.0.1";
}

function startScannerServer() {
  const htmlPath = path.join(__dirname, "assets", "scanner.html");
  const server = http.createServer((req, res) => {
    const cors = {
      "Access-Control-Allow-Origin":  "*",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };
    if (req.method === "OPTIONS") { res.writeHead(204, cors); return res.end(); }
    if (req.method === "GET" && req.url === "/") {
      try {
        res.writeHead(200, { ...cors, "Content-Type": "text/html; charset=utf-8" });
        res.end(fs.readFileSync(htmlPath, "utf8"));
      } catch { res.writeHead(404, cors); res.end("not found"); }
      return;
    }
    if (req.method === "POST" && req.url === "/scan") {
      let body = "";
      req.on("data", c => body += c);
      req.on("end", () => {
        try {
          const { ean } = JSON.parse(body);
          const eanStr = String(ean || "").trim();
          if (eanStr && /^\d{8,14}$/.test(eanStr)) {
            res.writeHead(200, { ...cors, "Content-Type": "application/json" });
            res.end(JSON.stringify({ ok: true }));
            mainWindow?.webContents.send("scanner:ean", eanStr);
          } else {
            res.writeHead(400, cors);
            res.end(JSON.stringify({ ok: false, error: "invalid ean" }));
          }
        } catch { res.writeHead(400, cors); res.end(); }
      });
      return;
    }

    // ── Extension Bridge Routes ───────────────────────────────────────────────

    // GET /token — returns the stored JWT + expiry for the extension to use
    if (req.method === "GET" && req.url === "/token") {
      (async () => {
        try {
          const token = await getToken();
          let exp = Date.now() + 7 * 24 * 3600 * 1000;
          if (token) {
            try {
              const pl = JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString());
              if (pl.exp) exp = pl.exp * 1000;
            } catch {}
          }
          res.writeHead(200, { ...cors, "Content-Type": "application/json" });
          res.end(JSON.stringify({ ok: !!token, token: token || null, exp }));
        } catch {
          res.writeHead(200, { ...cors, "Content-Type": "application/json" });
          res.end(JSON.stringify({ ok: false, token: null }));
        }
      })();
      return;
    }

    // GET /status — health-check / version info
    if (req.method === "GET" && req.url === "/status") {
      res.writeHead(200, { ...cors, "Content-Type": "application/json" });
      res.end(JSON.stringify({
        ok:      true,
        running: true,
        version: app.getVersion(),
        mode:    process.env.FLIPCHECK_MODE || "remote",
      }));
      return;
    }

    // GET /inventory — list all inventory items
    if (req.method === "GET" && req.url === "/inventory") {
      try {
        const { items } = readInv();
        res.writeHead(200, { ...cors, "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: true, items: Array.isArray(items) ? items : [] }));
      } catch {
        res.writeHead(200, { ...cors, "Content-Type": "application/json" });
        res.end(JSON.stringify({ ok: true, items: [] }));
      }
      return;
    }

    // POST /inventory — upsert item from extension
    if (req.method === "POST" && req.url === "/inventory") {
      let body = "";
      req.on("data", c => body += c);
      req.on("end", () => {
        try {
          const item = JSON.parse(body);
          // Reuse the existing upsert logic
          const store = readInv();
          const now   = Date.now();
          const idx   = store.items.findIndex(i => i.id === item.id || (item.ean && i.ean === item.ean));
          if (idx >= 0) {
            store.items[idx] = { ...store.items[idx], ...item, updatedAt: now };
          } else {
            store.items.unshift({
              id:        item.id || `${Date.now()}-${Math.random().toString(36).slice(2)}`,
              ean:       item.ean || "",
              title:     item.title || "",
              ek:        Number(item.ek) || 0,
              qty:       Number(item.qty) || 1,
              status:    item.status || "IN_STOCK",
              market:    item.market || "ebay",
              source:    item.source || "",
              notes:     item.notes || "",
              createdAt: now,
              updatedAt: now,
            });
          }
          writeInv(store);
          // Notify renderer for live update
          mainWindow?.webContents.send("inventory:upsert-ext", store.items[idx >= 0 ? idx : 0]);
          res.writeHead(200, { ...cors, "Content-Type": "application/json" });
          res.end(JSON.stringify({ ok: true }));
        } catch {
          res.writeHead(400, cors);
          res.end(JSON.stringify({ ok: false, error: "invalid_body" }));
        }
      });
      return;
    }

    res.writeHead(404, cors); res.end();
  });
  server.on("error", err => console.error("[Scanner] server error:", err.message));
  server.listen(8766, "0.0.0.0", () => console.log("[Scanner] HTTP server listening on :8766"));
  return server;
}

// ─── Backend Spawn ────────────────────────────────────────────────────────────
function getBackendDir() {
  return IS_PROD
    ? path.join(process.resourcesPath, "Backend")
    : path.join(__dirname, "..", "services", "auth");
}

function startBackend(port) {
  const dir = getBackendDir();
  const python = IS_PROD ? "python" : (() => {
    const venv = path.join(dir, ".venv", "Scripts", "python.exe");
    return fs.existsSync(venv) ? venv : "python";
  })();

  backendProc = spawn(python, ["-m", "uvicorn", "flipcheck_app:app", "--host", HOST, "--port", String(port), "--log-level", "warning"], {
    cwd: dir,
    env: { ...process.env, PORT: String(port) },
    stdio: ["ignore", "pipe", "pipe"],
    windowsHide: true,
  });

  backendProc.stdout.on("data", d => console.log("[backend]", d.toString().trim()));
  backendProc.stderr.on("data", d => console.error("[backend:err]", d.toString().trim()));
  backendProc.on("exit", (code) => console.log("[backend] exit:", code));
}

// ─── Window ───────────────────────────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 1000,
    minHeight: 640,
    backgroundColor: "#0A0A0F",
    title: "FLIPCHECK",
    show: false,
    titleBarStyle: "hidden",
    titleBarOverlay: { color: "#0A0A0F", symbolColor: "#ffffff", height: 32 },
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  // DevTools toggle (Cmd+Alt+I / Ctrl+Shift+I)
  mainWindow.webContents.on("before-input-event", (_e, input) => {
    const isMac = process.platform === "darwin";
    const toggle = isMac
      ? input.meta && input.alt && input.key.toLowerCase() === "i"
      : input.control && input.shift && input.key.toLowerCase() === "i";
    if (toggle) {
      mainWindow.webContents.isDevToolsOpened()
        ? mainWindow.webContents.closeDevTools()
        : mainWindow.webContents.openDevTools({ mode: "detach" });
    }
  });

  // External links open in browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("https://") || url.startsWith("http://")) {
      shell.openExternal(url);
    }
    return { action: "deny" };
  });

  mainWindow.once("ready-to-show", () => mainWindow.show());
  mainWindow.loadFile(APP_HTML);
}

// ─── Protocol handler ─────────────────────────────────────────────────────────
function parseToken(url) {
  try {
    const u = new URL(url);
    return u.protocol === "flipcheck:" ? u.searchParams.get("token") : null;
  } catch { return null; }
}

if (process.defaultApp) {
  app.setAsDefaultProtocolClient("flipcheck", process.execPath, [path.resolve(process.argv[1])]);
} else {
  app.setAsDefaultProtocolClient("flipcheck");
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", async (_e, argv) => {
    const deep = argv.find(a => typeof a === "string" && a.startsWith("flipcheck://"));
    if (!deep) return;
    const token = parseToken(deep);
    if (!token) return;
    await saveToken(token);
    if (mainWindow) { mainWindow.webContents.send("auth:token", token); mainWindow.show(); mainWindow.focus(); }
  });
}

app.on("open-url", async (e, url) => {
  e.preventDefault();
  const token = parseToken(url);
  if (!token) return;
  await saveToken(token);
  if (mainWindow) { mainWindow.webContents.send("auth:token", token); mainWindow.show(); mainWindow.focus(); }
});

// ─── App lifecycle ────────────────────────────────────────────────────────────
app.whenReady().then(async () => {
  app.setName("FLIPCHECK");

  if (MODE === "local") {
    BACKEND_PORT = await pickFreePort(PORT_FROM, PORT_TO);
    if (BACKEND_PORT) {
      startBackend(BACKEND_PORT);
      await waitForHttp(`http://${HOST}:${BACKEND_PORT}/health`, 12000);
    }
  }

  createWindow();

  // Barcode scanner HTTP server
  startScannerServer();

  // Auto-updater — only in packaged production builds
  if (IS_PROD && autoUpdater) {
    try {
      autoUpdater.on("update-available",  info => mainWindow?.webContents.send("updater:available",  info));
      autoUpdater.on("update-downloaded", info => mainWindow?.webContents.send("updater:downloaded", info));
      autoUpdater.on("error", err => console.error("[Updater]", err.message));
      setTimeout(() => autoUpdater.checkForUpdatesAndNotify().catch(() => {}), 5000);
    } catch (e) { console.error("[Updater] setup failed:", e.message); }
  }
});

app.on("window-all-closed", () => {
  if (backendProc) { try { backendProc.kill(); } catch {} }
  app.quit();
});

// ─── IPC: Config ──────────────────────────────────────────────────────────────
ipcMain.handle("cfg:backendBase", () => apiBase());
ipcMain.handle("cfg:mode", () => MODE);
ipcMain.handle("cfg:version", () => APP_VERSION);
ipcMain.handle("cfg:requireAuth", () => IS_PROD); // In dev/local mode: no auth required

// ─── IPC: Auth ────────────────────────────────────────────────────────────────
ipcMain.handle("auth:getToken", async () => {
  const token = await getToken();
  return { token };
});
ipcMain.handle("auth:login", () => shell.openExternal(AUTH_URL));
ipcMain.handle("auth:logout", async () => { await deleteToken(); return { ok: true }; });

// ─── IPC: Settings ────────────────────────────────────────────────────────────
ipcMain.handle("settings:get", () => loadSettings());
ipcMain.handle("settings:set", (_e, data) => saveSettings(data));

// ─── IPC: Device ──────────────────────────────────────────────────────────────
ipcMain.handle("device:fingerprint", () => {
  const raw = [os.hostname(), os.userInfo().username, os.platform(), os.arch()].join("|");
  return crypto.createHash("sha256").update(raw).digest("hex");
});

// ─── IPC: Inventory ───────────────────────────────────────────────────────────
ipcMain.handle("inventory:list", () => {
  const { items } = readInv();
  return [...items].sort((a, b) => (b.updated_at || "").localeCompare(a.updated_at || ""));
});

ipcMain.handle("inventory:upsert", (_e, item) => {
  const store = readInv();
  const norm = normalizeItem(item);
  const idx = store.items.findIndex(i => i.id === norm.id);
  if (idx >= 0) store.items[idx] = { ...store.items[idx], ...norm };
  else store.items.push(norm);
  writeInv(store);
  return norm;
});

ipcMain.handle("inventory:delete", (_e, { id }) => {
  const store = readInv();
  store.items = store.items.filter(i => i.id !== id);
  writeInv(store);
  return { ok: true };
});

ipcMain.handle("inventory:bulkUpdate", (_e, { ids, patch }) => {
  const store = readInv();
  const idSet = new Set(ids);
  store.items = store.items.map(i => {
    if (!idSet.has(i.id)) return i;
    return normalizeItem({ ...i, ...patch });
  });
  writeInv(store);
  return { ok: true, count: ids.length };
});

ipcMain.handle("inventory:clear", () => { writeInv({ version: 1, items: [] }); return { ok: true }; });

// ─── IPC: Price History ───────────────────────────────────────────────────────
ipcMain.handle("priceHistory:save", (_e, entry) => {
  const data = readHist();
  const { ean, title, ...rest } = entry;
  if (!data[ean]) data[ean] = { ean, title: title || ean, entries: [] };
  if (title) data[ean].title = title;
  data[ean].entries.push({ ts: nowIso(), ...rest });
  // Keep last 180 entries per EAN
  if (data[ean].entries.length > 180) data[ean].entries = data[ean].entries.slice(-180);
  writeHist(data);
  return { ok: true };
});

ipcMain.handle("priceHistory:get", (_e, ean) => {
  const data = readHist();
  return data[ean] || { ean, title: ean, entries: [] };
});

ipcMain.handle("priceHistory:list", () => {
  const data = readHist();
  return Object.values(data).map(d => ({
    ean: d.ean,
    title: d.title,
    count: d.entries.length,
    last_ts: d.entries[d.entries.length - 1]?.ts || null,
    last_price: d.entries[d.entries.length - 1]?.browse_median || null,
  }));
});

ipcMain.handle("priceHistory:deleteEan", (_e, ean) => {
  const data = readHist();
  delete data[ean];
  writeHist(data);
  return { ok: true };
});

// Saves 30-day daily series from eBay Research (metricsTrends).
// price_series: [[epoch_ms, avg_price], ...]
// qty_series:   [[epoch_ms, qty], ...]     (optional, same length, matched by index)
// Entries are deduped by day (yyyy-mm-dd) — existing days are NOT overwritten.
ipcMain.handle("priceHistory:saveSeries", (_e, { ean, title, price_series, qty_series }) => {
  if (!ean || !Array.isArray(price_series) || price_series.length === 0) return { ok: false };
  const data = readHist();
  if (!data[ean]) data[ean] = { ean, title: title || ean, entries: [] };
  if (title) data[ean].title = title;

  // Build a set of existing dates (yyyy-mm-dd) to avoid duplicates
  const existingDays = new Set(
    data[ean].entries.map(e => (e.ts || "").slice(0, 10))
  );

  // Build a qty lookup: epoch_ms → qty
  const qtyMap = new Map((qty_series || []).map(([ts, q]) => [ts, q]));

  let added = 0;
  for (const [epochMs, price] of price_series) {
    if (price == null) continue;
    const day = new Date(epochMs).toISOString().slice(0, 10);
    if (existingDays.has(day)) continue;   // skip — already have data for this day
    existingDays.add(day);
    data[ean].entries.push({
      ts:           new Date(epochMs).toISOString(),
      research_avg: price,                 // daily avg sold price from Research
      qty:          qtyMap.get(epochMs) ?? null,  // daily units sold
      from_series:  true,                  // flag: came from metricsTrends, not a live check
    });
    added++;
  }

  // Sort entries chronologically and cap at 365
  data[ean].entries.sort((a, b) => a.ts.localeCompare(b.ts));
  if (data[ean].entries.length > 365) data[ean].entries = data[ean].entries.slice(-365);

  writeHist(data);
  return { ok: true, added };
});

// ─── IPC: Seller Tracker ──────────────────────────────────────────────────────
const SELLERS_FILE = path.join(app.getPath("userData"), "tracked_sellers.json");

function readSellers() {
  try {
    if (!fs.existsSync(SELLERS_FILE)) return [];
    return JSON.parse(fs.readFileSync(SELLERS_FILE, "utf8") || "[]") || [];
  } catch { return []; }
}

function writeSellers(list) {
  try { fs.writeFileSync(SELLERS_FILE, JSON.stringify(list, null, 2), "utf8"); } catch {}
}

ipcMain.handle("competition:list",   () => readSellers());

ipcMain.handle("competition:add", (_e, username) => {
  const list = readSellers();
  if (!list.find(s => s.username === username)) {
    list.unshift({ username, added_at: new Date().toISOString(), listing_count: null });
    writeSellers(list);
  }
  return readSellers();
});

ipcMain.handle("competition:remove", (_e, username) => {
  writeSellers(readSellers().filter(s => s.username !== username));
  return readSellers();
});

ipcMain.handle("competition:updateCount", (_e, { username, count, feedback_score, feedback_pct }) => {
  const list = readSellers();
  const s = list.find(x => x.username === username);
  if (s) {
    s.listing_count = count;
    s.last_checked  = new Date().toISOString();
    if (feedback_score != null) s.feedback_score = feedback_score;
    if (feedback_pct  != null) s.feedback_pct   = feedback_pct;
  }
  writeSellers(list);
  return { ok: true };
});

// ─── IPC: Price Alerts ────────────────────────────────────────────────────────
const { Notification: ElectronNotif } = require("electron");
const ALERTS_FILE = path.join(app.getPath("userData"), "price_alerts.json");

function readAlerts() {
  try {
    if (!fs.existsSync(ALERTS_FILE)) return [];
    return JSON.parse(fs.readFileSync(ALERTS_FILE, "utf8") || "[]") || [];
  } catch { return []; }
}
function writeAlerts(list) {
  try { fs.writeFileSync(ALERTS_FILE, JSON.stringify(list, null, 2), "utf8"); } catch {}
}

ipcMain.handle("alerts:list", () => readAlerts());

ipcMain.handle("alerts:add", (_e, { ean, target_price, title }) => {
  const list = readAlerts();
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  list.unshift({
    id, ean,
    title:           title || null,
    target_price:    parseFloat(target_price),
    created_at:      new Date().toISOString(),
    last_checked:    null,
    last_price:      null,
    triggered:       false,
    triggered_at:    null,
    triggered_price: null,
    active:          true,
    check_count:     0,
  });
  writeAlerts(list);
  return readAlerts();
});

ipcMain.handle("alerts:remove", (_e, id) => {
  writeAlerts(readAlerts().filter(a => a.id !== id));
  return readAlerts();
});

ipcMain.handle("alerts:update", (_e, patch) => {
  const list = readAlerts();
  const idx  = list.findIndex(a => a.id === patch.id);
  if (idx !== -1) {
    // Track trigger history when an alert is newly triggered
    if (patch.triggered && patch.triggered_price != null) {
      const hist = list[idx].trigger_history || [];
      hist.push({ ts: patch.triggered_at || new Date().toISOString(), price: patch.triggered_price });
      patch.trigger_history = hist.slice(-20); // keep last 20 entries
    }
    Object.assign(list[idx], patch);
  }
  writeAlerts(list);
  return readAlerts();
});

ipcMain.handle("alerts:reset", (_e, id) => {
  const list = readAlerts();
  const a = list.find(x => x.id === id);
  if (a) {
    a.triggered = false; a.triggered_at = null;
    a.triggered_price = null; a.active = true;
    a.trigger_history = []; // clear history on reset
  }
  writeAlerts(list);
  return readAlerts();
});

ipcMain.handle("notify", (_e, title, body) => {
  try {
    if (ElectronNotif.isSupported()) {
      new ElectronNotif({ title, body }).show();
    }
  } catch {}
  return true;
});

// ─── IPC: Scanner ─────────────────────────────────────────────────────────────
ipcMain.handle("scanner:getInfo", () => {
  const ip = getLocalIP();
  return { url: `http://${ip}:8766`, ip };
});

// ─── IPC: Auto-Updater ────────────────────────────────────────────────────────
ipcMain.handle("updater:check", async () => {
  if (!IS_PROD || !autoUpdater) return { checking: false, reason: "dev mode or unavailable" };
  try { await autoUpdater.checkForUpdatesAndNotify(); return { checking: true }; }
  catch (e) { return { checking: false, error: e.message }; }
});

ipcMain.handle("updater:install", () => {
  if (autoUpdater) try { autoUpdater.quitAndInstall(); } catch {}
});
