const { contextBridge, ipcRenderer } = require("electron");
const os = require("os");
const crypto = require("crypto");

function deviceFingerprint() {
  const raw = [os.hostname(), os.userInfo().username, os.platform(), os.arch()].join("|");
  return crypto.createHash("sha256").update(raw).digest("hex");
}

// Scanner IPC listener map (needed for proper removeListener with wrapped fns)
const _scannerListeners = new Map();

contextBridge.exposeInMainWorld("fc", {
  // Config
  backendBase: () => ipcRenderer.invoke("cfg:backendBase"),
  mode: () => ipcRenderer.invoke("cfg:mode"),
  version: () => ipcRenderer.invoke("cfg:version"),
  requireAuth: () => ipcRenderer.invoke("cfg:requireAuth"),

  // Auth
  getToken: async () => (await ipcRenderer.invoke("auth:getToken"))?.token || null,
  login: () => ipcRenderer.invoke("auth:login"),
  logout: () => ipcRenderer.invoke("auth:logout"),
  onAuthToken: (fn) => ipcRenderer.on("auth:token", (_e, token) => fn(token)),

  // Settings
  getSettings: () => ipcRenderer.invoke("settings:get"),
  setSettings: (data) => ipcRenderer.invoke("settings:set", data),

  // Device
  fingerprint: () => deviceFingerprint(),
  deviceName: () => `${os.hostname()} (${os.platform()} ${os.arch()})`,
  platform: () => process.platform,

  // Inventory
  inventoryList: () => ipcRenderer.invoke("inventory:list"),
  inventoryUpsert: (item) => ipcRenderer.invoke("inventory:upsert", item),
  inventoryDelete: (id) => ipcRenderer.invoke("inventory:delete", { id }),
  inventoryBulkUpdate: (ids, patch) => ipcRenderer.invoke("inventory:bulkUpdate", { ids, patch }),
  inventoryClear: () => ipcRenderer.invoke("inventory:clear"),

  // Price History
  priceHistorySave:       (entry)  => ipcRenderer.invoke("priceHistory:save",       entry),
  priceHistorySaveSeries: (params) => ipcRenderer.invoke("priceHistory:saveSeries", params),
  priceHistoryGet:        (ean)    => ipcRenderer.invoke("priceHistory:get",        ean),
  priceHistoryList:       ()       => ipcRenderer.invoke("priceHistory:list"),
  priceHistoryDeleteEan:  (ean)    => ipcRenderer.invoke("priceHistory:deleteEan",  ean),

  // Seller / Competition Tracker
  competitionList:        ()            => ipcRenderer.invoke("competition:list"),
  competitionAdd:         (username)    => ipcRenderer.invoke("competition:add",         username),
  competitionRemove:      (username)    => ipcRenderer.invoke("competition:remove",      username),
  competitionUpdateCount: (username, count, feedback_score, feedback_pct) => ipcRenderer.invoke("competition:updateCount", { username, count, feedback_score, feedback_pct }),

  // Price Alerts
  alertsList:   ()       => ipcRenderer.invoke("alerts:list"),
  alertsAdd:    (data)   => ipcRenderer.invoke("alerts:add",    data),
  alertsRemove: (id)     => ipcRenderer.invoke("alerts:remove", id),
  alertsUpdate: (patch)  => ipcRenderer.invoke("alerts:update", patch),
  alertsReset:  (id)     => ipcRenderer.invoke("alerts:reset",  id),

  // Desktop Notifications
  notify: (title, body) => ipcRenderer.invoke("notify", title, body),

  // Barcode Scanner
  getScannerInfo: () => ipcRenderer.invoke("scanner:getInfo"),
  onScannerEan: (cb) => {
    const wrapped = (_e, ean) => cb(ean);
    _scannerListeners.set(cb, wrapped);
    ipcRenderer.on("scanner:ean", wrapped);
  },
  offScannerEan: (cb) => {
    const wrapped = _scannerListeners.get(cb);
    if (wrapped) {
      ipcRenderer.removeListener("scanner:ean", wrapped);
      _scannerListeners.delete(cb);
    }
  },

  // Auto-Updater
  checkForUpdates:    ()   => ipcRenderer.invoke("updater:check"),
  installUpdate:      ()   => ipcRenderer.invoke("updater:install"),
  onUpdateAvailable:  (cb) => ipcRenderer.on("updater:available",  (_e, info) => cb(info)),
  onUpdateDownloaded: (cb) => ipcRenderer.on("updater:downloaded", (_e, info) => cb(info)),

  // Extension Bridge — receive inventory upserts from the browser extension
  onInventoryUpsertExt: (cb) => ipcRenderer.on("inventory:upsert-ext", (_e, item) => cb(item)),
});
