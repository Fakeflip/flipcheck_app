/* Flipcheck v2 — Inventory View */
const InventoryView = (() => {
  let _container = null;
  let _items = [];
  let _selected = new Set();
  let _filter = { q: "", status: "", market: "" };

  const STATUSES = ["IN_STOCK","LISTED","LISTING_PENDING","INBOUND","SOLD","RETURN","ARCHIVED"];
  const STATUS_LABELS = {
    IN_STOCK: "Auf Lager", LISTED: "Gelistet", LISTING_PENDING: "Pending",
    INBOUND: "Unterwegs", SOLD: "Verkauft", RETURN: "Rücksendung", ARCHIVED: "Archiviert",
  };
  const MARKETS = ["ebay","amz","kaufland","other"];

  async function mount(container) {
    _container = container;
    _selected = new Set();
    _filter = { q: "", status: "", market: "" };
    container.innerHTML = renderShell();
    attachFilterEvents(container);
    attachTableDelegation(container); // delegated listeners — set once
    await loadItems(container);

    // Extension Bridge — live upsert from browser extension via POST /inventory
    window.fc?.onInventoryUpsertExt?.((item) => {
      if (item && _container) {
        Storage.upsertItem(item).then(() => loadItems(_container)).catch(() => {});
      }
    });
  }

  function unmount() { _container = null; }

  function renderShell() {
    return `
      <div class="page-header">
        <div class="page-header-left">
          <h1>Inventory</h1>
          <p id="invCount">Lade…</p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-primary btn-sm" id="btnAddItem">
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M8 1v14M1 8h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
            Hinzufügen
          </button>
          <button class="btn btn-secondary btn-sm" id="btnRefreshInv">
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M2 8a6 6 0 1 0 1.5-3.9M2 2v4h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
        </div>
      </div>

      <!-- Filters -->
      <div class="inv-filters">
        <input id="invSearch" class="input" type="search" placeholder="Suche nach Titel, EAN, SKU…" style="flex:1;max-width:280px" />
        <select id="invStatusFilter" class="select">
          <option value="">Alle Status</option>
          ${STATUSES.map(s => `<option value="${s}">${STATUS_LABELS[s]}</option>`).join("")}
        </select>
        <select id="invMarketFilter" class="select">
          <option value="">Alle Märkte</option>
          ${MARKETS.map(m => `<option value="${m}">${m.toUpperCase()}</option>`).join("")}
        </select>
      </div>

      <!-- Bulk Bar -->
      <div id="invBulkBar" class="inv-bulk-bar" style="display:none">
        <span id="invBulkCount">0 ausgewählt</span>
        <select id="invBulkStatus" class="select" style="max-width:160px;font-size:12px;padding:4px 8px;height:28px">
          <option value="">Status setzen…</option>
          ${STATUSES.map(s => `<option value="${s}">${STATUS_LABELS[s]}</option>`).join("")}
        </select>
        <button class="btn btn-secondary btn-sm" id="btnBulkApply">Anwenden</button>
        <button class="btn btn-danger btn-sm" id="btnBulkDelete">
          <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M2 4h12M5 4V2h6v2M6 7v5M10 7v5M3 4l1 10h8l1-10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
          Löschen
        </button>
        <button class="btn btn-ghost btn-sm" id="btnBulkCancel" style="margin-left:auto">Abbrechen</button>
      </div>

      <!-- Table -->
      <div class="panel" style="padding:0;overflow:hidden">
        <div id="invTableWrap">
          <div class="empty-state" style="padding:40px">
            <div class="spinner"></div>
          </div>
        </div>
      </div>
    `;
  }

  async function loadItems(container) {
    try {
      _items = await Storage.listInventory();
    } catch {
      _items = [];
    }
    renderTable(container);
    updateCount(container);
  }

  function getFiltered() {
    const q = _filter.q.toLowerCase();
    return _items.filter(i => {
      if (_filter.status && i.status !== _filter.status) return false;
      if (_filter.market && i.market !== _filter.market) return false;
      if (q) {
        const hay = `${i.title} ${i.ean} ${i.sku} ${i.label}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }

  function renderTable(container) {
    const wrap = container?.querySelector("#invTableWrap");
    if (!wrap) return;
    const filtered = getFiltered();

    if (filtered.length === 0) {
      wrap.innerHTML = `
        <div class="empty-state">
          <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-4 0v2M12 12v4M10 14h4"/></svg>
          <p class="empty-title">Keine Artikel</p>
          <p class="empty-sub">${_filter.q || _filter.status || _filter.market ? "Keine Artikel mit diesen Filtern gefunden." : "Noch keine Artikel im Inventory. Klicke auf \"Hinzufügen\"."}</p>
        </div>
      `;
      return;
    }

    const allChecked = filtered.length > 0 && filtered.every(i => _selected.has(i.id));

    wrap.innerHTML = `
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th style="width:36px"><input type="checkbox" id="invSelectAll" ${allChecked ? "checked" : ""} /></th>
              <th>Artikel</th>
              <th>Markt</th>
              <th class="col-right">EK</th>
              <th class="col-right">VK</th>
              <th class="col-right">Profit</th>
              <th>Status</th>
              <th class="col-right">Alter</th>
              <th style="width:80px"></th>
            </tr>
          </thead>
          <tbody>
            ${filtered.map(i => renderRow(i)).join("")}
          </tbody>
        </table>
      </div>
    `;

  }

  function renderRow(item) {
    const profit = item.sell_price && item.ek ? item.sell_price - item.ek : null;
    const age = item.created_at ? Math.floor((Date.now() - new Date(item.created_at)) / 86400000) : null;
    const checked = _selected.has(item.id);

    return `
      <tr>
        <td><input type="checkbox" class="inv-row-check" data-id="${esc(item.id)}" ${checked ? "checked" : ""} /></td>
        <td>
          <div style="font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:220px" title="${esc(item.title)}">${esc(item.title||item.ean||"—")}</div>
          <div class="text-xs text-muted">${esc(item.ean||"")}</div>
          ${item.source ? `<div class="text-xs" style="color:var(--text-muted);margin-top:2px">📦 ${esc(item.source)}</div>` : ""}
          ${item.label ? `<span class="badge badge-gray" style="margin-top:2px;font-size:10px">${esc(item.label)}</span>` : ""}
        </td>
        <td><span class="badge badge-gray" style="font-size:10px">${esc((item.market||"—").toUpperCase())}</span></td>
        <td class="col-right col-num">${fmtEur(item.ek)}</td>
        <td class="col-right col-num">${fmtEur(item.sell_price)}</td>
        <td class="col-right col-num ${profit > 0 ? "text-green" : profit < 0 ? "text-red" : ""}">${fmtEur(profit)}</td>
        <td><span class="badge status-${item.status||"IN_STOCK"}">${esc(STATUS_LABELS[item.status] || item.status || "—")}</span></td>
        <td class="col-right text-muted text-sm">${age != null ? `${age}d` : "—"}</td>
        <td>
          <div class="row" style="gap:4px;justify-content:flex-end">
            ${item.status !== "SOLD" ? `<button class="btn btn-ghost btn-icon btn-inv-sold" data-id="${esc(item.id)}" title="Als verkauft markieren">
              <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M3 8l4 4 6-7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </button>` : ""}
            <button class="btn btn-ghost btn-icon btn-inv-edit" data-id="${esc(item.id)}" title="Bearbeiten">
              <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M11 2l3 3-9 9H2v-3L11 2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </button>
          </div>
        </td>
      </tr>
    `;
  }

  function updateCount(container) {
    const el = container?.querySelector("#invCount");
    if (!el) return;
    const f = getFiltered();
    el.textContent = `${_items.length} Artikel · ${f.length} angezeigt`;
  }

  function updateBulkBar(container) {
    const bar = container?.querySelector("#invBulkBar");
    const count = container?.querySelector("#invBulkCount");
    if (!bar) return;
    if (_selected.size > 0) {
      bar.style.display = "flex";
      if (count) count.textContent = `${_selected.size} ausgewählt`;
    } else {
      bar.style.display = "none";
    }
  }

  function attachFilterEvents(container) {
    container.querySelector("#invSearch")?.addEventListener("input", e => {
      _filter.q = e.target.value;
      renderTable(container);
      updateCount(container);
    });

    container.querySelector("#invStatusFilter")?.addEventListener("change", e => {
      _filter.status = e.target.value;
      renderTable(container);
      updateCount(container);
    });

    container.querySelector("#invMarketFilter")?.addEventListener("change", e => {
      _filter.market = e.target.value;
      renderTable(container);
      updateCount(container);
    });

    container.querySelector("#btnAddItem")?.addEventListener("click", () => openAddModal(container));
    container.querySelector("#btnRefreshInv")?.addEventListener("click", () => loadItems(container));

    container.querySelector("#btnBulkApply")?.addEventListener("click", async () => {
      const status = container.querySelector("#invBulkStatus")?.value;
      if (!status) { Toast.warning("Kein Status", "Bitte einen Status auswählen."); return; }
      const ids = [..._selected];
      await Storage.bulkUpdate(ids, { status });
      _selected.clear();
      await loadItems(container);
      updateBulkBar(container);
      Toast.success("Aktualisiert", `${ids.length} Artikel auf "${STATUS_LABELS[status]}" gesetzt.`);
    });

    container.querySelector("#btnBulkDelete")?.addEventListener("click", async () => {
      const ok = await Modal.confirm("Löschen bestätigen", `${_selected.size} Artikel wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.`, { confirmLabel: "Löschen", danger: true });
      if (!ok) return;
      const ids = [..._selected];
      for (const id of ids) await Storage.deleteItem(id);
      _selected.clear();
      await loadItems(container);
      updateBulkBar(container);
      Toast.success("Gelöscht", `${ids.length} Artikel gelöscht.`);
    });

    container.querySelector("#btnBulkCancel")?.addEventListener("click", () => {
      _selected.clear();
      renderTable(container);
      updateBulkBar(container);
    });
  }

  function attachTableDelegation(container) {
    // Single delegated listener on the stable container — handles all dynamic table events
    container.addEventListener("change", e => {
      // Select-all checkbox
      if (e.target.id === "invSelectAll") {
        const filtered = getFiltered();
        if (e.target.checked) filtered.forEach(i => _selected.add(i.id));
        else filtered.forEach(i => _selected.delete(i.id));
        renderTable(container);
        updateBulkBar(container);
        return;
      }
      // Row checkbox
      if (e.target.classList.contains("inv-row-check")) {
        const id = e.target.dataset.id;
        if (e.target.checked) _selected.add(id);
        else _selected.delete(id);
        updateBulkBar(container);
      }
    });

    container.addEventListener("click", e => {
      const editBtn = e.target.closest(".btn-inv-edit");
      if (editBtn) { openEditModal(editBtn.dataset.id, container); return; }

      const soldBtn = e.target.closest(".btn-inv-sold");
      if (soldBtn) { openSoldModal(soldBtn.dataset.id, container); return; }
    });
  }

  function openAddModal(container) {
    const body = `
      <div class="col gap-12">
        <div class="input-group">
          <label class="input-label">EAN *</label>
          <input id="mEan" class="input" type="text" placeholder="Barcode" autocomplete="off" />
        </div>
        <div class="input-group">
          <label class="input-label">Titel</label>
          <input id="mTitle" class="input" type="text" placeholder="Produktname" />
        </div>
        <div class="grid-2" style="gap:12px">
          <div class="input-group">
            <label class="input-label">Einkaufspreis (€)</label>
            <input id="mEk" class="input" type="number" step="0.01" min="0" placeholder="0.00" />
          </div>
          <div class="input-group">
            <label class="input-label">Menge</label>
            <input id="mQty" class="input" type="number" min="1" value="1" />
          </div>
        </div>
        <div class="grid-2" style="gap:12px">
          <div class="input-group">
            <label class="input-label">Markt</label>
            <select id="mMarket" class="select">
              ${MARKETS.map(m => `<option value="${m}">${m.toUpperCase()}</option>`).join("")}
            </select>
          </div>
          <div class="input-group">
            <label class="input-label">Status</label>
            <select id="mStatus" class="select">
              ${STATUSES.map(s => `<option value="${s}" ${s==="IN_STOCK"?"selected":""}>${STATUS_LABELS[s]}</option>`).join("")}
            </select>
          </div>
        </div>
        <div class="input-group">
          <label class="input-label">Label</label>
          <input id="mLabel" class="input" type="text" placeholder="Tag, Kategorie…" />
        </div>
        <div class="input-group">
          <label class="input-label">Bezugsquelle</label>
          <input id="mSource" class="input" type="text" placeholder="z.B. Amazon, Lidl, OBI…" />
        </div>
      </div>
    `;

    Modal.open({
      title: "Artikel hinzufügen",
      body,
      buttons: [
        { label: "Abbrechen", variant: "btn-ghost", value: false },
        { label: "Hinzufügen", variant: "btn-primary", action: async () => {
          const ean = document.getElementById("mEan")?.value.trim();
          if (!ean) { Toast.error("EAN fehlt", "Bitte eine EAN eingeben."); return; }
          await Storage.upsertItem({
            ean,
            title: document.getElementById("mTitle")?.value.trim() || "",
            ek: parseFloat(document.getElementById("mEk")?.value) || null,
            qty: parseInt(document.getElementById("mQty")?.value) || 1,
            market: document.getElementById("mMarket")?.value || "ebay",
            status: document.getElementById("mStatus")?.value || "IN_STOCK",
            label: document.getElementById("mLabel")?.value.trim() || "",
            source: document.getElementById("mSource")?.value.trim() || "",
          });
          Modal.close(true);
          await loadItems(container);
          Toast.success("Hinzugefügt", `${ean} wurde zum Inventory hinzugefügt.`);
        }},
      ],
    });
  }

  function openEditModal(id, container) {
    const item = _items.find(i => i.id === id);
    if (!item) return;

    const body = `
      <div class="col gap-12">
        <div class="input-group">
          <label class="input-label">Titel</label>
          <input id="eTitle" class="input" type="text" value="${esc(item.title||"")}" />
        </div>
        <div class="input-group">
          <label class="input-label">EAN</label>
          <input id="eEan" class="input" type="text" value="${esc(item.ean||"")}" />
        </div>
        <div class="grid-2" style="gap:12px">
          <div class="input-group">
            <label class="input-label">EK (€)</label>
            <input id="eEk" class="input" type="number" step="0.01" value="${item.ek||""}" />
          </div>
          <div class="input-group">
            <label class="input-label">Menge</label>
            <input id="eQty" class="input" type="number" min="1" value="${item.qty||1}" />
          </div>
        </div>
        <div class="grid-2" style="gap:12px">
          <div class="input-group">
            <label class="input-label">Markt</label>
            <select id="eMarket" class="select">
              ${MARKETS.map(m => `<option value="${m}" ${item.market===m?"selected":""}>${m.toUpperCase()}</option>`).join("")}
            </select>
          </div>
          <div class="input-group">
            <label class="input-label">Status</label>
            <select id="eStatus" class="select">
              ${STATUSES.map(s => `<option value="${s}" ${item.status===s?"selected":""}>${STATUS_LABELS[s]}</option>`).join("")}
            </select>
          </div>
        </div>
        <div class="input-group">
          <label class="input-label">Label</label>
          <input id="eLabel" class="input" type="text" value="${esc(item.label||"")}" />
        </div>
        <div class="input-group">
          <label class="input-label">Bezugsquelle</label>
          <input id="eSource" class="input" type="text" value="${esc(item.source||"")}" placeholder="z.B. Amazon, Lidl, OBI" />
        </div>
        <div class="input-group">
          <label class="input-label">Notiz</label>
          <textarea id="eNotes" class="textarea" rows="2">${esc(item.notes||"")}</textarea>
        </div>
      </div>
    `;

    Modal.open({
      title: `Artikel bearbeiten`,
      body,
      buttons: [
        { label: "Löschen", variant: "btn-danger", action: async () => {
          const ok = await Modal.confirm("Löschen?", `"${item.title||item.ean}" wirklich löschen?`, { confirmLabel: "Löschen", danger: true });
          if (!ok) return;
          await Storage.deleteItem(id);
          await loadItems(container);
          Toast.success("Gelöscht");
        }},
        { label: "Abbrechen", variant: "btn-ghost", value: false },
        { label: "Speichern", variant: "btn-primary", action: async () => {
          await Storage.upsertItem({
            ...item,
            title: document.getElementById("eTitle")?.value.trim() || item.title,
            ean: document.getElementById("eEan")?.value.trim() || item.ean,
            ek: parseFloat(document.getElementById("eEk")?.value) || item.ek,
            qty: parseInt(document.getElementById("eQty")?.value) || item.qty,
            market: document.getElementById("eMarket")?.value || item.market,
            status: document.getElementById("eStatus")?.value || item.status,
            label: document.getElementById("eLabel")?.value.trim() || "",
            source: document.getElementById("eSource")?.value.trim() || "",
            notes: document.getElementById("eNotes")?.value.trim() || "",
          });
          Modal.close(true);
          await loadItems(container);
          Toast.success("Gespeichert");
        }},
      ],
    });
  }

  function openSoldModal(id, container) {
    const item = _items.find(i => i.id === id);
    if (!item) return;

    const body = `
      <div class="col gap-12">
        <p class="text-secondary text-sm">"${esc(item.title||item.ean)}" als verkauft markieren.</p>
        <div class="input-group">
          <label class="input-label">Verkaufspreis (€) *</label>
          <div class="input-prefix-wrap">
            <span class="prefix">€</span>
            <input id="soldVk" class="input" type="number" step="0.01" min="0" placeholder="0.00" />
          </div>
        </div>
        <div class="input-group">
          <label class="input-label">Verkaufsdatum</label>
          <input id="soldDate" class="input" type="date" value="${new Date().toISOString().slice(0,10)}" />
        </div>
        ${item.ek ? `<div class="hint-text">Einkauf: ${fmtEur(item.ek)} · Profit wird automatisch berechnet</div>` : ""}
      </div>
    `;

    Modal.open({
      title: "Als verkauft markieren",
      body,
      buttons: [
        { label: "Abbrechen", variant: "btn-ghost", value: false },
        { label: "Verkauft", variant: "btn-success", action: async () => {
          const vk = parseFloat(document.getElementById("soldVk")?.value);
          if (!vk || vk <= 0) { Toast.error("VK fehlt", "Bitte einen Verkaufspreis eingeben."); return; }
          const soldDate = document.getElementById("soldDate")?.value;
          await Storage.upsertItem({
            ...item,
            status: "SOLD",
            sell_price: vk,
            sold_at: soldDate ? new Date(soldDate).toISOString() : new Date().toISOString(),
          });
          Modal.close(true);
          await loadItems(container);
          const profit = item.ek ? fmtEur(vk - item.ek) : "";
          Toast.success("Verkauft", `${profit ? `Profit: ${profit}` : "Artikel als verkauft markiert."}`);
        }},
      ],
    });
  }

  return { mount, unmount };
})();
