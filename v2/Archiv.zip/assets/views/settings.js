/* Flipcheck v2 — Settings View */
const SettingsView = (() => {
  let _container = null;

  async function mount(container) {
    _container = container;
    const settings = await Storage.getSettings().catch(() => ({}));
    container.innerHTML = renderView(settings);
    attachEvents(container, settings);
    loadProfile(container);
  }

  function unmount() { _container = null; }

  function renderView(s) {
    const profit = s?.analytics?.weekly_profit_target || "";
    const vat = s?.tax?.vat_mode || "no_vat";
    const defaultMarket = s?.defaults?.market || "ebay";
    const defaultMode = s?.defaults?.flipcheck_mode || "mid";
    const ekMode = s?.defaults?.ek_mode || "gross";

    return `
      <div class="page-header">
        <div class="page-header-left">
          <h1>Einstellungen</h1>
          <p>App-Konfiguration und Präferenzen</p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-primary btn-sm" id="btnSaveSettings">
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M2 2h8l4 4v8H2V2zM5 2v5h7M5 10h6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            Speichern
          </button>
        </div>
      </div>

      <div style="max-width:600px">

        <!-- Mein Konto -->
        <div class="settings-section">
          <div class="settings-section-title">Mein Konto</div>
          <div class="panel panel-sm" id="profileSection">
            <div class="settings-row" style="border:none;gap:12px">
              <div class="skeleton" style="width:48px;height:48px;border-radius:50%;flex-shrink:0"></div>
              <div class="col" style="gap:6px;flex:1">
                <div class="skeleton" style="width:130px;height:14px"></div>
                <div class="skeleton" style="width:90px;height:11px"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Analytics -->
        <div class="settings-section">
          <div class="settings-section-title">Analytics</div>
          <div class="panel panel-sm">
            <div class="settings-row">
              <div class="settings-row-left">
                <h4>Wöchentliches Profit-Ziel</h4>
                <p>Wird auf dem Analytics-Dashboard angezeigt</p>
              </div>
              <div class="input-prefix-wrap" style="width:120px">
                <span class="prefix">€</span>
                <input id="sWeeklyTarget" class="input" type="number" min="0" step="10" value="${esc(String(profit))}" style="text-align:right;padding-right:12px;padding-left:26px" />
              </div>
            </div>
          </div>
        </div>

        <!-- Steuern / MwSt -->
        <div class="settings-section">
          <div class="settings-section-title">Steuer & MwSt</div>
          <div class="panel panel-sm">
            <div class="settings-row">
              <div class="settings-row-left">
                <h4>MwSt-Modus</h4>
                <p>Wie Preise im Profit-Rechner behandelt werden</p>
              </div>
              <select id="sVatMode" class="select" style="width:180px">
                <option value="no_vat" ${vat==="no_vat"?"selected":""}>Kleinunternehmer (0%)</option>
                <option value="ust_19" ${vat==="ust_19"?"selected":""}>Regelbesteuerung (19%)</option>
              </select>
            </div>
            <div class="settings-row">
              <div class="settings-row-left">
                <h4>EK-Eingabe Standard</h4>
                <p>Brutto (inkl. MwSt) oder Netto</p>
              </div>
              <div class="seg" id="sEkModeSeg">
                <button class="seg-btn ${ekMode==="gross"?"active":""}" data-val="gross">Brutto</button>
                <button class="seg-btn ${ekMode==="net"?"active":""}" data-val="net">Netto</button>
              </div>
            </div>
          </div>
        </div>

        <!-- Defaults -->
        <div class="settings-section">
          <div class="settings-section-title">Standard-Werte</div>
          <div class="panel panel-sm">
            <div class="settings-row">
              <div class="settings-row-left">
                <h4>Standard-Markt</h4>
                <p>Vorausgewählter Marktplatz</p>
              </div>
              <select id="sDefaultMarket" class="select" style="width:160px">
                <option value="ebay" ${defaultMarket==="ebay"?"selected":""}>eBay</option>
                <option value="amz" ${defaultMarket==="amz"?"selected":""}>Amazon</option>
                <option value="kaufland" ${defaultMarket==="kaufland"?"selected":""}>Kaufland</option>
              </select>
            </div>
            <div class="settings-row">
              <div class="settings-row-left">
                <h4>Standard-Flipcheck-Modus</h4>
                <p>Vorausgwählter Analyse-Modus</p>
              </div>
              <div class="seg" id="sModeSeg">
                <button class="seg-btn ${defaultMode==="low"?"active":""}" data-val="low">LOW</button>
                <button class="seg-btn ${defaultMode==="mid"?"active":""}" data-val="mid">MID</button>
                <button class="seg-btn ${defaultMode==="high"?"active":""}" data-val="high">HIGH</button>
              </div>
            </div>
          </div>
        </div>

        <!-- Gefahrenzone -->
        <div class="settings-section">
          <div class="settings-section-title">Gefahrenzone</div>
          <div class="panel panel-sm" style="border-color:var(--red-border)">
            <div class="settings-row">
              <div class="settings-row-left">
                <h4>Inventory zurücksetzen</h4>
                <p>Alle Artikel aus dem Inventory löschen</p>
              </div>
              <button class="btn btn-danger btn-sm" id="btnClearInventory">Inventory löschen</button>
            </div>
            <div class="settings-row" style="border:none">
              <div class="settings-row-left">
                <h4>Logout</h4>
                <p>Abmelden und Token löschen</p>
              </div>
              <button class="btn btn-danger btn-sm" id="btnSettingsLogout">Logout</button>
            </div>
          </div>
        </div>

        <!-- App Info -->
        <div class="panel panel-sm">
          <div class="settings-row">
            <div class="settings-row-left">
              <h4>Version</h4>
              <p id="settingsVersion">Lade…</p>
            </div>
            <div id="updaterStatus" class="text-xs" style="text-align:right;color:var(--text-muted)"></div>
          </div>
          <div class="settings-row" style="border:none">
            <div class="settings-row-left">
              <h4>Updates</h4>
              <p>Automatischer Download bei neuem Release</p>
            </div>
            <div style="display:flex;gap:8px;align-items:center;flex-shrink:0">
              <button class="btn btn-secondary btn-sm" id="btnCheckUpdates">Nach Updates suchen</button>
              <button class="btn btn-primary btn-sm" id="btnInstallUpdate" style="display:none">↺ Jetzt installieren</button>
            </div>
          </div>
        </div>

      </div>
    `;
  }

  function attachEvents(container, settings) {
    // Seg buttons
    container.querySelectorAll("#sEkModeSeg .seg-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        container.querySelectorAll("#sEkModeSeg .seg-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
      });
    });
    container.querySelectorAll("#sModeSeg .seg-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        container.querySelectorAll("#sModeSeg .seg-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
      });
    });

    // Save settings
    container.querySelector("#btnSaveSettings")?.addEventListener("click", async () => {
      const patch = {
        analytics: {
          weekly_profit_target: parseFloat(container.querySelector("#sWeeklyTarget")?.value) || 0,
        },
        tax: {
          vat_mode: container.querySelector("#sVatMode")?.value || "no_vat",
          ek_mode: container.querySelector("#sEkModeSeg .seg-btn.active")?.dataset.val || "gross",
        },
        defaults: {
          market: container.querySelector("#sDefaultMarket")?.value || "ebay",
          flipcheck_mode: container.querySelector("#sModeSeg .seg-btn.active")?.dataset.val || "mid",
        },
      };
      await Storage.saveSettings(patch);
      Toast.success("Gespeichert", "Einstellungen wurden gespeichert.");
    });

    // Danger zone
    container.querySelector("#btnClearInventory")?.addEventListener("click", async () => {
      const ok = await Modal.confirm("Inventory löschen", "Wirklich alle Artikel aus dem Inventory löschen? Diese Aktion kann nicht rückgängig gemacht werden.", { confirmLabel: "Alles löschen", danger: true });
      if (!ok) return;
      try {
        await window.fc.inventoryClear();
        Toast.success("Gelöscht", "Inventory wurde zurückgesetzt.");
      } catch {
        Toast.error("Fehler", "Inventory konnte nicht gelöscht werden.");
      }
    });

    container.querySelector("#btnSettingsLogout")?.addEventListener("click", async () => {
      const ok = await Modal.confirm("Ausloggen", "Wirklich ausloggen?", { confirmLabel: "Ausloggen", danger: true });
      if (!ok) return;
      try { await window.fc.logout(); } catch {}
      window.location.reload();
    });

    // Version
    window.fc?.version?.().then(v => {
      const el = container.querySelector("#settingsVersion");
      if (el) el.textContent = `FLIPCHECK v${v || "2.0.0"}`;
    }).catch(() => {});

    // Auto-updater
    container.querySelector("#btnCheckUpdates")?.addEventListener("click", async () => {
      const btn = container.querySelector("#btnCheckUpdates");
      const statusEl = container.querySelector("#updaterStatus");
      btn.disabled = true;
      btn.textContent = "Prüfe…";
      try { await window.fc?.checkForUpdates?.(); } catch {}
      setTimeout(() => {
        btn.disabled = false;
        btn.textContent = "Nach Updates suchen";
        if (statusEl && !statusEl.dataset.hasUpdate) {
          statusEl.textContent = "Auf dem neuesten Stand ✓";
          setTimeout(() => { if (statusEl && !statusEl.dataset.hasUpdate) statusEl.textContent = ""; }, 4000);
        }
      }, 3500);
    });

    container.querySelector("#btnInstallUpdate")?.addEventListener("click", () => {
      window.fc?.installUpdate?.();
    });

    window.fc?.onUpdateAvailable?.((info) => {
      const statusEl = container.querySelector("#updaterStatus");
      if (!statusEl) return;
      statusEl.dataset.hasUpdate = "1";
      statusEl.innerHTML = `<span style="color:var(--accent)">Update verfügbar: v${info?.version || "?"} — wird geladen…</span>`;
    });

    window.fc?.onUpdateDownloaded?.((info) => {
      const statusEl = container.querySelector("#updaterStatus");
      if (statusEl) {
        statusEl.dataset.hasUpdate = "1";
        statusEl.innerHTML = `<span style="color:var(--green)">v${info?.version || "?"} bereit zum Installieren</span>`;
      }
      const installBtn = container.querySelector("#btnInstallUpdate");
      if (installBtn) installBtn.style.display = "";
    });
  }

  async function loadProfile(container) {
    const profileSection = container.querySelector("#profileSection");
    if (!profileSection) return;
    try {
      const r = await API.call("/auth/me");
      if (!r.ok || !r.data) throw new Error("not_ok");
      const u = r.data;
      const plan = (u.plan || "FREE").toUpperCase();
      const planColor = { FREE: "#475569", PRO: "#6366F1", LIFETIME: "#F59E0B" }[plan] || "#475569";
      const initials  = (u.username || u.email || "?").slice(0, 2).toUpperCase();
      profileSection.innerHTML = `
        <div class="settings-row" style="border:none;align-items:center;gap:0">
          <div style="display:flex;align-items:center;gap:12px;flex:1">
            ${u.avatar_url
              ? `<img src="${u.avatar_url}" class="profile-avatar" alt="" onerror="this.replaceWith(document.getElementById('_pf_fb_${u.id || 0}'))" />
                 <div class="profile-avatar profile-avatar-fallback" id="_pf_fb_${u.id || 0}" style="display:none">${initials}</div>`
              : `<div class="profile-avatar profile-avatar-fallback">${initials}</div>`
            }
            <div>
              <div style="font-weight:700;font-size:14px;color:var(--text-primary)">${String(u.username || u.email || "—").replace(/&/g,"&amp;").replace(/</g,"&lt;")}</div>
              ${u.email && u.email !== u.username ? `<div class="text-xs text-muted">${String(u.email).replace(/&/g,"&amp;").replace(/</g,"&lt;")}</div>` : ""}
            </div>
          </div>
          <span class="profile-plan-badge" style="background:${planColor}22;color:${planColor};border:1px solid ${planColor}44">${plan}</span>
        </div>
      `;
    } catch {
      profileSection.innerHTML = `
        <div class="settings-row" style="border:none">
          <div class="settings-row-left">
            <h4>Nicht angemeldet</h4>
            <p>Bitte neu einloggen</p>
          </div>
          <button class="btn btn-primary btn-sm" onclick="window.location.reload()">Login</button>
        </div>
      `;
    }
  }

  return { mount, unmount };
})();
