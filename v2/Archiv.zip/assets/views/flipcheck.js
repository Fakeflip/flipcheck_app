/* Flipcheck v2 — Single Flipcheck View */
const FlipcheckView = (() => {
  let _container = null;

  // ─── eBay DE category fee structure (Ohne Shop, official rates) ───────────
  // tiers: [[threshold_up_to, rate], ..., [null, rate_above]]
  // e.g. [[990, 0.065], [null, 0.03]] → 6,5% bis €990, 3% darüber
  const CATEGORIES = [
    // ── Geräte: 6,5 % bis €990, danach 3 % ──────────────────────────────
    { id: "computer_tablets",  label: "Computer, Tablets & Netzwerk",  group: "Geräte (6,5% + 3%)",  tiers: [[990, 0.065], [null, 0.03]] },
    { id: "drucker",           label: "Drucker",                        group: "Geräte (6,5% + 3%)",  tiers: [[990, 0.065], [null, 0.03]] },
    { id: "foto_camcorder",    label: "Foto & Camcorder",               group: "Geräte (6,5% + 3%)",  tiers: [[990, 0.065], [null, 0.03]] },
    { id: "handys",            label: "Handys & Kommunikation",         group: "Geräte (6,5% + 3%)",  tiers: [[990, 0.065], [null, 0.03]] },
    { id: "haushaltsgeraete",  label: "Haushaltsgeräte",                group: "Geräte (6,5% + 3%)",  tiers: [[990, 0.065], [null, 0.03]] },
    { id: "konsolen",          label: "Konsolen / Videospiele",         group: "Geräte (6,5% + 3%)",  tiers: [[990, 0.065], [null, 0.03]] },
    { id: "scanner",           label: "Scanner",                        group: "Geräte (6,5% + 3%)",  tiers: [[990, 0.065], [null, 0.03]] },
    { id: "speicherkarten",    label: "Speicherkarten",                 group: "Geräte (6,5% + 3%)",  tiers: [[990, 0.065], [null, 0.03]] },
    { id: "tv_video_audio",    label: "TV, Video & Audio",              group: "Geräte (6,5% + 3%)",  tiers: [[990, 0.065], [null, 0.03]] },
    { id: "koerperpflege",     label: "Elektr. Körperpflege & Styling", group: "Geräte (6,5% + 3%)",  tiers: [[990, 0.065], [null, 0.03]] },
    // ── Zubehör: 11 % bis €990, danach 3 % ──────────────────────────────
    { id: "drucker_zubehoer",  label: "Drucker- & Scanner-Zubehör",    group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "handy_zubehoer",    label: "Handy-Zubehör",                  group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "batterien",         label: "Haushaltsbatterien & Strom",     group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "kabel",             label: "Kabel & Steckverbinder",         group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "kameras_zubehoer",  label: "Kameras, Drohnen & Fotozubehör",group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "notebook_zubehoer", label: "Notebook- & Desktop-Zubehör",   group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "objektive",         label: "Objektive & Filter",             group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "stative",           label: "Stative & Zubehör",             group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "tablet_zubehoer",   label: "Tablet & eBook Zubehör",        group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "tastaturen_maeuse", label: "Tastaturen, Mäuse & Pointing",   group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "tv_zubehoer",       label: "TV- & Heim-Audio-Zubehör",      group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "pc_zubehoer",       label: "PC & Videospiele Zubehör",      group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    { id: "audio_zubehoer",    label: "Zubehör Audiogeräte",           group: "Zubehör (11% + 3%)",  tiers: [[990, 0.11], [null, 0.03]] },
    // ── Sonstige Flat-Rate ───────────────────────────────────────────────
    { id: "mode",              label: "Mode / Bekleidung",              group: "Sonstiges (Flat)",     tiers: [[null, 0.15]]  },
    { id: "sport_freizeit",    label: "Sport & Freizeit",               group: "Sonstiges (Flat)",     tiers: [[null, 0.115]] },
    { id: "spielzeug",         label: "Spielzeug / LEGO",               group: "Sonstiges (Flat)",     tiers: [[null, 0.115]] },
    { id: "haushalt_garten",   label: "Haushalt & Garten",              group: "Sonstiges (Flat)",     tiers: [[null, 0.115]] },
    { id: "buecher",           label: "Bücher & Medien",                group: "Sonstiges (Flat)",     tiers: [[null, 0.15]]  },
    { id: "sonstiges",         label: "Sonstiges",                      group: "Sonstiges (Flat)",     tiers: [[null, 0.13]]  },
  ];

  // ─── Tiered fee calculator (mirrors backend _calc_tiered_fee) ─────────────
  function calcEbayFee(priceGross, catId) {
    const cat = CATEGORIES.find(c => c.id === catId) || CATEGORIES[CATEGORIES.length - 1];
    let fee = 0, remaining = Math.max(0, priceGross), prev = 0;
    for (const [threshold, rate] of cat.tiers) {
      if (threshold === null) { fee += remaining * rate; break; }
      const chunk = Math.min(remaining, threshold - prev);
      fee += chunk * rate;
      remaining -= chunk;
      prev = threshold;
      if (remaining <= 0) break;
    }
    return fee;
  }

  // ─── Full profit calc (frontend-side, tiered fees + VAT) ─────────────────
  // Returns { feeGross, feeNet, vkNet, ekNet, siNet, soNet, packNet, profit, margin }
  function calcProfit(vkGross, ekGross, catId, vatMode, ekMode, shipInGross, shipOutGross, packagingPerUnit = 0, qty = 1) {
    const vat      = vatMode === "ust_19" ? 1.19 : 1.0;
    const feeGross = calcEbayFee(vkGross, catId);
    const feeNet   = feeGross / vat;
    const vkNet    = vkGross  / vat;
    const ekNet    = (vatMode === "ust_19" && ekMode === "gross") ? ekGross / vat : ekGross;
    const siNet    = shipInGross  / vat;
    const soNet    = shipOutGross / vat;
    const packNet  = packagingPerUnit; // packaging is already a net cost (no VAT recovery on packaging typically)
    const profit   = vkNet - feeNet - ekNet - siNet - soNet - packNet;
    const margin   = vkGross > 0 ? (profit / vkGross * 100) : 0;
    return { feeGross, feeNet, vkNet, ekNet, siNet, soNet, packNet, profit, margin };
  }

  function buildCatOptions(selectedId) {
    const groups = {};
    for (const c of CATEGORIES) {
      if (!groups[c.group]) groups[c.group] = [];
      groups[c.group].push(c);
    }
    return Object.entries(groups).map(([grp, cats]) =>
      `<optgroup label="${esc(grp)}">${
        cats.map(c => `<option value="${c.id}"${c.id === selectedId ? " selected" : ""}>${esc(c.label)}</option>`).join("")
      }</optgroup>`
    ).join("");
  }

  // ─── State ────────────────────────────────────────────────────────────────
  let selectedMode = "mid";
  let _vatMode   = "no_vat";
  let _ekMode    = "gross";
  let lastResult = null;
  let lastEan    = null;
  let lastEk     = null;
  let _miniChart = null;   // Chart.js instance for the inline price sparkline

  // ─── Scanner IPC callback (stable ref for add/remove) ─────────────────────
  function _onScannerEan(ean) {
    if (!_container) return;
    const inp = _container.querySelector("#fcEan");
    if (!inp) return;
    inp.value = ean;
    inp.dispatchEvent(new Event("input"));
    inp.focus();
    if (typeof Toast !== "undefined") Toast.success("EAN gescannt", ean);
  }

  // ─── Mount ────────────────────────────────────────────────────────────────
  async function mount(container, navId) {
    _container = container;

    // Load settings for VAT / EK mode
    try {
      const s = await Storage.getSettings();
      _vatMode = s?.tax?.vat_mode  || "no_vat";
      _ekMode  = s?.tax?.ek_mode   || "gross";
      selectedMode = s?.defaults?.flipcheck_mode || "mid";
    } catch {}

    // Guard: user may have navigated away during async load
    if (navId !== undefined && navId !== null && typeof App !== "undefined" && App._navId !== navId) return;

    container.innerHTML = renderForm();
    attachEvents(container);

    // Register barcode scanner IPC listener
    window.fc?.onScannerEan(_onScannerEan);
  }

  function unmount() {
    if (_miniChart) { try { _miniChart.destroy(); } catch {} _miniChart = null; }
    window.fc?.offScannerEan(_onScannerEan);
    _container = null;
  }

  // ─── Form ─────────────────────────────────────────────────────────────────
  function renderForm(state = {}) {
    const catId = state.category || "sonstiges";
    const vatBadge = _vatMode === "ust_19"
      ? `<div style="display:flex;align-items:center;gap:6px;margin-top:6px;padding:7px 10px;background:rgba(99,102,241,0.08);border:1px solid rgba(99,102,241,0.2);border-radius:var(--r)">
           <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6.5" stroke="#6366F1" stroke-width="1.2"/><path d="M8 5v3.5M8 10.5v.5" stroke="#6366F1" stroke-width="1.5" stroke-linecap="round"/></svg>
           <span class="text-xs" style="color:var(--accent)">Regelbesteuerung 19% MwSt — Preise werden netto gerechnet</span>
         </div>`
      : `<div style="display:flex;align-items:center;gap:6px;margin-top:6px;padding:7px 10px;background:var(--bg-elevated);border:1px solid var(--border);border-radius:var(--r)">
           <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6.5" stroke="var(--text-muted)" stroke-width="1.2"/><path d="M5 8h6" stroke="var(--text-muted)" stroke-width="1.5" stroke-linecap="round"/></svg>
           <span class="text-xs text-muted">Kleinunternehmer — keine MwSt-Anpassung</span>
         </div>`;

    return `
      <div class="page-header">
        <div class="page-header-left">
          <h1>Flipcheck</h1>
          <p>EAN prüfen — ist das Produkt profitabel?</p>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:420px 1fr;gap:20px;align-items:start">
        <!-- Form -->
        <div class="panel">
          <h3 class="panel-title">Produkt analysieren</h3>

          <div class="col gap-12">
            <div class="input-group">
              <label class="input-label">EAN / ASIN</label>
              <div style="display:flex;gap:6px">
                <input id="fcEan" class="input" type="text" placeholder="z.B. 4010355360205"
                  value="${esc(state.ean||"")}" autocomplete="off" style="flex:1" />
                <button class="btn btn-ghost btn-sm" id="fcScanBtn" title="Handy-Scanner öffnen" style="flex-shrink:0;font-size:16px;padding:0 10px">📷</button>
              </div>
            </div>

            <div class="input-group">
              <label class="input-label">Einkaufspreis (€${_ekMode==="gross"&&_vatMode==="ust_19"?" brutto, inkl. 19% MwSt":""} )</label>
              <div class="input-prefix-wrap">
                <span class="prefix">€</span>
                <input id="fcEk" class="input" type="number" step="0.01" min="0" placeholder="0.00"
                  value="${esc(state.ek||"")}" />
              </div>
            </div>

            <div class="input-group">
              <label class="input-label">eBay Kategorie</label>
              <select id="fcCategory" class="select">${buildCatOptions(catId)}</select>
              ${vatBadge}
            </div>

            <div class="input-group">
              <label class="input-label">Versandkosten${_vatMode==="ust_19"?" (brutto, inkl. MwSt)":""}</label>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                <div>
                  <div class="text-xs text-muted mb-4">Einkauf (rein)</div>
                  <div class="input-prefix-wrap">
                    <span class="prefix">€</span>
                    <input id="fcShipIn" class="input" type="number" step="0.01" min="0" placeholder="0.00"
                      value="${esc(state.shipping_in||"")}" />
                  </div>
                </div>
                <div>
                  <div class="text-xs text-muted mb-4">Verkauf (raus)</div>
                  <div class="input-prefix-wrap">
                    <span class="prefix">€</span>
                    <input id="fcShipOut" class="input" type="number" step="0.01" min="0" placeholder="0.00"
                      value="${esc(state.shipping_out||"")}" />
                  </div>
                </div>
              </div>
            </div>

            <div class="input-group">
              <label class="input-label">Verpackungskosten (€ pro Einheit)</label>
              <div class="input-prefix-wrap">
                <span class="prefix">€</span>
                <input id="fcPackaging" class="input" type="number" step="0.01" min="0" placeholder="0.00"
                  value="${esc(state.packaging||"")}" title="Karton, Polsterung, Klebeband etc." />
              </div>
              <span class="input-hint">Bleibt erhalten bis du die Seite verlässt</span>
            </div>

            <div class="input-group">
              <label class="input-label">Modus</label>
              <div class="seg" id="fcModeSeg">
                <button class="seg-btn ${(!state.mode||state.mode===selectedMode)&&selectedMode==="mid"?"active":state.mode==="mid"?"active":""}" data-mode="mid">MID</button>
                <button class="seg-btn ${selectedMode==="high"||state.mode==="high"?"active":""}" data-mode="high">HIGH</button>
                <button class="seg-btn ${selectedMode==="low"||state.mode==="low"?"active":""}" data-mode="low">LOW</button>
                <button class="seg-btn ${selectedMode==="custom"||state.mode==="custom"?"active":""}" data-mode="custom">CUSTOM</button>
              </div>
              <span class="input-hint" id="fcModeHint">${getModeHint(selectedMode)}</span>
            </div>

            <button class="btn btn-primary" id="btnCheck" style="width:100%;justify-content:center;margin-top:4px">
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M8.5 1.5L2 9h5.5L7 14.5L14 7H8.5L8.5 1.5z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>
              Jetzt prüfen
            </button>
          </div>
        </div>

        <!-- Result -->
        <div id="fcResult">${renderResultPlaceholder()}</div>
      </div>
    `;
  }

  function getModeHint(mode) {
    return { mid:"Standard — Margin ≥20%, Profit ≥€7, ≤14 Tage", high:"Konservativ — Margin ≥25%, Profit ≥€10, ≤10 Tage", low:"Aggressiv — Margin ≥15%, Profit ≥€5, ≤21 Tage", custom:"Eigene Schwellenwerte (in Einstellungen konfigurierbar)" }[mode] || "";
  }

  function renderResultPlaceholder() {
    return `<div class="empty-state">
      <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width:48px;height:48px"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
      <p class="empty-title" style="font-size:14px">Bereit zur Analyse</p>
      <p class="empty-sub">EAN und Einkaufspreis eingeben, dann auf "Jetzt prüfen" klicken.</p>
    </div>`;
  }

  function renderLoading() {
    return `<div style="display:flex;align-items:center;justify-content:center;padding:60px;gap:12px">
      <div class="spinner"></div>
      <span class="text-secondary">eBay-Daten werden abgerufen…</span>
    </div>`;
  }

  // ─── Result Card ──────────────────────────────────────────────────────────
  function renderResult(data, ean, ek, catId, shipIn, shipOut) {
    const v  = data.verdict || "SKIP";
    const vc = v.toLowerCase();

    const vk    = data.sell_price_median ?? data.sell_price_avg ?? null;
    const days  = data.days_to_cash ?? null;
    const sales = data.sales_30d ?? null;
    const isVAT = _vatMode === "ust_19";

    // ── Frontend-side profit calculation (tiered fees + VAT, always correct) ──
    // Works regardless of which backend version is running.
    const packagingCost = parseFloat(_container?.querySelector("#fcPackaging")?.value) || 0;
    let calc = null;
    if (vk != null) {
      calc = calcProfit(
        vk,
        parseFloat(ek),
        catId,
        _vatMode,
        _ekMode,
        parseFloat(shipIn)  || 0,
        parseFloat(shipOut) || 0,
        packagingCost,
      );
    }

    const dispProfit = calc?.profit ?? (data.profit_median ?? data.profit_avg ?? null);
    const dispMargin = calc?.margin ?? (data.margin_pct ?? null);
    const dispVkNet  = calc?.vkNet  ?? vk;
    const dispEkNet  = calc?.ekNet  ?? parseFloat(ek);
    const dispFee    = calc?.feeNet ?? null;
    const dispSoNet  = calc?.soNet  ?? 0;
    const dispSiNet  = calc?.siNet  ?? 0;

    return `
      <div class="result-card ${vc}">
        <!-- Header -->
        <div class="row-between mb-16">
          <div>
            <div class="text-xs text-muted mb-8">${esc(data.title || ean)}</div>
            <div class="verdict-badge ${vc}">
              ${v==="BUY"
                ? `<svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M3 8l4 4 6-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`
                : v==="HOLD"
                ? `<svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M8 2v7M5 12h6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`
                : `<svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M2 2l12 12M14 2L2 14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`}
              ${v}
            </div>
          </div>
          <div class="col" style="align-items:flex-end;gap:4px">
            <span class="text-xs text-muted">EAN</span>
            <span class="text-mono text-sm font-semibold">${esc(ean)}</span>
          </div>
        </div>

        <!-- KPI Grid -->
        <div class="breakdown-grid">
          <div class="breakdown-item">
            <div class="breakdown-label">Einkauf${isVAT?" (netto)":""}</div>
            <div class="breakdown-val">${fmtEur(dispEkNet)}</div>
          </div>
          <div class="breakdown-item">
            <div class="breakdown-label">Ø VK${isVAT?" (netto)":""}</div>
            <div class="breakdown-val">${fmtEur(dispVkNet)}</div>
          </div>
          <div class="breakdown-item">
            <div class="breakdown-label">Profit${isVAT?" (netto)":""}</div>
            <div class="breakdown-val ${dispProfit > 0 ? "text-green" : dispProfit < 0 ? "text-red" : ""}">${fmtEur(dispProfit)}</div>
          </div>
          <div class="breakdown-item">
            <div class="breakdown-label">Margin</div>
            <div class="breakdown-val ${dispMargin >= 20 ? "text-green" : dispMargin >= 10 ? "text-yellow" : "text-red"}">${fmtPct(dispMargin)}</div>
          </div>
          <div class="breakdown-item">
            <div class="breakdown-label">Days to Cash</div>
            <div class="breakdown-val">${days ? fmtDays(days) : "—"}</div>
          </div>
          <div class="breakdown-item">
            <div class="breakdown-label">Verkäufe/30d</div>
            <div class="breakdown-val">${sales != null ? sales : "—"}</div>
          </div>
        </div>

        <!-- Profit Breakdown -->
        ${vk != null ? `
        <div style="margin-top:16px">
          <div class="text-xs text-muted font-semibold mb-8" style="text-transform:uppercase;letter-spacing:.06em">
            Profit Breakdown${isVAT ? " (Regelbesteuerung 19% MwSt)" : ""}
          </div>
          <div style="background:var(--bg-base);border:1px solid var(--border);border-radius:var(--r);overflow:hidden">
            ${isVAT ? `
              ${_brkRow("Verkaufspreis (brutto)", fmtEur(vk), "")}
              ${_brkRow("÷ 1,19 MwSt (19%)", "−"+fmtEur(vk - dispVkNet), "text-muted")}
              ${_brkRow("Netto-VK", fmtEur(dispVkNet), "text-secondary")}
            ` : `
              ${_brkRow("Verkaufspreis (Median)", fmtEur(vk), "")}
            `}
            ${dispFee != null ? _brkRow("eBay Gebühr", "−"+fmtEur(dispFee), "text-red") : ""}
            ${dispSoNet > 0 ? _brkRow(`Versand Verkauf${isVAT?" (netto)":""}`, "−"+fmtEur(dispSoNet), "text-red") : ""}
            ${isVAT
              ? _brkRow(`EK (netto${_ekMode==="gross"?" ÷1,19":"" })`, "−"+fmtEur(dispEkNet), "text-red")
              : _brkRow("Einkaufspreis (EK)", "−"+fmtEur(dispEkNet), "text-red")
            }
            ${dispSiNet > 0 ? _brkRow(`Versand Einkauf${isVAT?" (netto)":""}`, "−"+fmtEur(dispSiNet), "text-red") : ""}
            ${calc?.packNet > 0 ? _brkRow("Verpackung", "−"+fmtEur(calc.packNet), "text-red") : ""}
            <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 14px;border-top:1px solid var(--border);background:var(--bg-elevated)">
              <span class="text-sm font-semibold text-primary">Profit${isVAT?" (netto)":""}</span>
              <span class="text-sm font-semibold ${dispProfit > 0 ? "text-green" : dispProfit < 0 ? "text-red" : ""}">${fmtEur(dispProfit)}</span>
            </div>
          </div>
        </div>` : ""}

        <!-- Reason -->
        ${(data.error || data.reason) ? `
          <div style="margin-top:14px;padding:10px 12px;background:rgba(255,255,255,0.03);border-radius:var(--r);border:1px solid var(--border)">
            <span class="text-xs text-muted">Begründung: </span>
            <span class="text-xs text-secondary">${esc(data.error || data.reason)}</span>
          </div>` : ""}

        <!-- Actions -->
        <div class="row mt-16" style="gap:8px;flex-wrap:wrap">
          ${v !== "SKIP" ? `
          <button class="btn btn-primary btn-sm" id="btnCreateListing">
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
              <rect x="1" y="2" width="10" height="13" rx="1.2" stroke="currentColor" stroke-width="1.5"/>
              <path d="M4 6h4M4 9h3M11 10l2 2 2-2M13 8v4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            Listing erstellen
          </button>` : ""}
          <button class="btn btn-secondary btn-sm" id="btnAddToInv">
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><rect x="1" y="5" width="14" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/><path d="M5 5V4a3 3 0 0 1 6 0v1M6 10h4M8 8v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
            Zu Inventory
          </button>
          <button class="btn btn-ghost btn-sm" id="btnReset">Neu prüfen</button>
        </div>
      </div>

      <!-- Inline price history chart — populated after history is loaded -->
      <div id="fcPriceChart" style="margin-top:12px"></div>
    `;
  }

  function _brkRow(label, value, valClass = "") {
    return `<div style="display:flex;justify-content:space-between;align-items:center;padding:7px 14px;border-bottom:1px solid var(--border)">
      <span class="text-xs text-secondary">${esc(label)}</span>
      <span class="text-xs font-semibold ${valClass}">${value}</span>
    </div>`;
  }

  function renderError(msg) {
    return `<div class="result-card" style="border-color:var(--red-border)">
      <div class="row gap-8 mb-8">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="7" stroke="#EF4444" stroke-width="1.5"/><path d="M5.5 5.5l5 5M10.5 5.5l-5 5" stroke="#EF4444" stroke-width="1.5" stroke-linecap="round"/></svg>
        <span class="font-bold text-red">Fehler</span>
      </div>
      <p class="text-secondary text-sm">${esc(msg)}</p>
      <button class="btn btn-ghost btn-sm mt-8" id="btnReset">Erneut versuchen</button>
    </div>`;
  }

  // ─── Inline Price Chart ───────────────────────────────────────────────────
  // price_series (optional): [[epoch_ms, avg_price], ...] from Research API
  // qty_series   (optional): [[epoch_ms, qty], ...]
  // Falls back to stored history if no series provided.
  async function loadPriceChart(ean, resultEl, price_series, qty_series) {
    const chartWrap = resultEl.querySelector("#fcPriceChart");
    if (!chartWrap) return;

    // ── Build chart entries ────────────────────────────────────────────────
    // Prefer fresh series from API response (31 daily data points, immediate)
    let chartEntries = [];

    if (Array.isArray(price_series) && price_series.length >= 2) {
      // Convert [[epoch_ms, price], ...] to chart entry objects
      const qtyMap = new Map((qty_series || []).map(([ts, q]) => [ts, q]));
      chartEntries = price_series
        .filter(([, p]) => p != null)
        .map(([epochMs, price]) => ({
          ts:           new Date(epochMs).toISOString(),
          research_avg: price,
          qty:          qtyMap.get(epochMs) ?? null,
        }));
    } else {
      // Fallback: load accumulated history from storage
      try {
        const histData = await Storage.getHistory(ean);
        chartEntries = (histData.entries || []).slice(-60);
      } catch { return; }
    }

    if (chartEntries.length < 2) {
      chartWrap.innerHTML = `
        <div style="padding:10px 14px;background:var(--bg-panel);border:1px solid var(--border);border-radius:var(--r);display:flex;align-items:center;gap:8px">
          <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6.5" stroke="#475569" stroke-width="1.2"/><path d="M8 5v3.5M8 10.5v.5" stroke="#475569" stroke-width="1.5" stroke-linecap="round"/></svg>
          <span class="text-xs text-muted">Noch keine Preishistorie für diese EAN verfügbar.</span>
        </div>`;
      return;
    }

    // ── Stats for header ───────────────────────────────────────────────────
    const prices    = chartEntries.map(e => e.research_avg ?? e.browse_median ?? e.browse_avg).filter(Boolean);
    const minPrice  = Math.min(...prices);
    const maxPrice  = Math.max(...prices);
    const firstPrc  = prices[0];
    const lastPrice = prices[prices.length - 1];
    const pctChange = firstPrc > 0 ? ((lastPrice - firstPrc) / firstPrc * 100) : 0;
    const trendDir  = pctChange > 1.5 ? "up" : pctChange < -1.5 ? "down" : "flat";
    const trendColor= trendDir === "up" ? "var(--green)" : trendDir === "down" ? "var(--red)" : "var(--text-muted)";
    const trendLabel= trendDir === "flat" ? "Stabil" : `${pctChange > 0 ? "+" : ""}${pctChange.toFixed(1)}%`;
    const isFromSeries = Array.isArray(price_series) && price_series.length >= 2;
    const periodLabel  = isFromSeries ? "letzte 30 Tage (eBay Research)" : `letzte ${chartEntries.length} Checks`;

    chartWrap.innerHTML = `
      <div class="panel" style="padding:14px 16px">
        <div class="row-between mb-12">
          <div class="row gap-8" style="align-items:center">
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><polyline points="1,12 5,7 9,10 15,3" stroke="#6366F1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            <span class="text-xs font-semibold text-secondary" style="text-transform:uppercase;letter-spacing:.06em">Preisverlauf — ${periodLabel}</span>
          </div>
          <div class="row gap-12" style="align-items:center">
            <span class="text-xs text-muted">Min: <strong style="color:var(--green)">${fmtEur(minPrice)}</strong></span>
            <span class="text-xs text-muted">Max: <strong style="color:var(--red)">${fmtEur(maxPrice)}</strong></span>
            <span class="text-xs font-semibold" style="color:${trendColor}">${trendLabel}</span>
          </div>
        </div>
        <div style="height:110px;position:relative">
          <canvas id="fcMiniChart"></canvas>
        </div>
      </div>
    `;

    if (_miniChart) { try { _miniChart.destroy(); } catch {} _miniChart = null; }
    const ctx = chartWrap.querySelector("#fcMiniChart");
    if (!ctx) return;

    // When showing a series, also render a bar dataset for daily quantity
    const hasQty = isFromSeries && chartEntries.some(e => e.qty != null);

    _miniChart = new Chart(ctx, {
      type: "bar",  // mixed chart
      data: {
        labels: chartEntries.map(e => {
          const d = new Date(e.ts);
          return `${d.getDate()}.${d.getMonth()+1}.`;
        }),
        datasets: [
          // Qty bars (background, right y-axis)
          ...(hasQty ? [{
            type: "bar",
            label: "Verkäufe",
            data: chartEntries.map(e => e.qty ?? 0),
            backgroundColor: "rgba(99,102,241,0.12)",
            borderColor: "transparent",
            borderWidth: 0,
            yAxisID: "yQty",
            order: 2,
          }] : []),
          // Price line (foreground)
          {
            type: "line",
            label: "Ø Verkaufspreis",
            data: chartEntries.map(e => e.research_avg ?? e.browse_median ?? e.browse_avg ?? null),
            borderColor: "#6366F1",
            backgroundColor: "rgba(99,102,241,0.06)",
            borderWidth: 2,
            fill: !hasQty,
            tension: 0.35,
            pointRadius: chartEntries.length <= 14 ? 3 : 1,
            pointHoverRadius: 5,
            pointBackgroundColor: "#6366F1",
            pointBorderColor: "transparent",
            spanGaps: true,
            yAxisID: "yPrice",
            order: 1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { intersect: false, mode: "index" },
        plugins: {
          legend: {
            position: "top",
            align: "end",
            labels: { font: { size: 10, family: "Inter, sans-serif" }, color: "#94A3B8", boxWidth: 8, boxHeight: 2, padding: 10 },
          },
          tooltip: {
            backgroundColor: "#16161F",
            borderColor: "#2E2E42",
            borderWidth: 1,
            titleColor: "#F1F5F9",
            bodyColor: "#94A3B8",
            titleFont: { size: 10 },
            bodyFont: { size: 10 },
            callbacks: {
              label: c => c.dataset.label === "Verkäufe"
                ? ` Verkäufe: ${c.parsed.y}`
                : ` ${c.dataset.label}: ${fmtEur(c.parsed.y)}`,
            },
          },
        },
        scales: {
          x: {
            grid: { color: "rgba(30,30,46,0.5)", drawBorder: false },
            ticks: { font: { size: 9 }, color: "#475569", maxTicksLimit: 8, maxRotation: 0 },
          },
          yPrice: {
            position: "left",
            grid: { color: "rgba(30,30,46,0.5)", drawBorder: false },
            ticks: { font: { size: 9 }, color: "#475569", callback: v => fmtEur(v), maxTicksLimit: 4 },
          },
          ...(hasQty ? {
            yQty: {
              position: "right",
              grid: { drawOnChartArea: false },
              ticks: { font: { size: 9 }, color: "#475569", maxTicksLimit: 3 },
            },
          } : {}),
        },
      },
    });
  }

  // ─── Scanner Modal ────────────────────────────────────────────────────────
  async function openScannerModal() {
    let scanInfo = null;
    try { scanInfo = await window.fc?.getScannerInfo(); } catch {}
    const url  = scanInfo?.url || "http://<IP>:8766";
    const body = `
      <div style="text-align:center">
        <p style="font-size:13px;color:var(--text-secondary);margin-bottom:16px">
          Öffne diese URL auf deinem Handy und scanne Barcodes direkt in Flipcheck.
        </p>
        <div style="background:var(--bg-base);border:1px solid var(--border);border-radius:10px;padding:16px 20px;margin-bottom:16px">
          <div style="font-family:monospace;font-size:16px;font-weight:700;color:var(--accent);letter-spacing:.02em;word-break:break-all">${esc(url)}</div>
        </div>
        <button class="btn btn-secondary btn-sm" id="scanUrlCopy" style="margin-bottom:12px">
          📋 URL kopieren
        </button>
        <p style="font-size:11px;color:var(--text-muted)">
          Handy & PC müssen im selben WLAN sein.<br>
          Gescannte EANs erscheinen automatisch im EAN-Feld.
        </p>
      </div>
    `;
    if (typeof Modal !== "undefined") {
      Modal.open({ title: "📷 Handy-Scanner", body, buttons: [{ label: "Schließen", variant: "btn-ghost", value: false }] });
      // Copy button
      setTimeout(() => {
        document.getElementById("scanUrlCopy")?.addEventListener("click", () => {
          navigator.clipboard?.writeText(url).then(() => {
            if (typeof Toast !== "undefined") Toast.success("Kopiert", url);
          }).catch(() => {});
        });
      }, 50);
    }
  }

  // ─── Events ───────────────────────────────────────────────────────────────
  function attachEvents(container) {
    container.querySelectorAll("#fcModeSeg .seg-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        container.querySelectorAll("#fcModeSeg .seg-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        selectedMode = btn.dataset.mode;
        const hint = container.querySelector("#fcModeHint");
        if (hint) hint.textContent = getModeHint(selectedMode);
      });
    });

    container.querySelector("#btnCheck")?.addEventListener("click", () => runCheck(container));
    container.querySelector("#fcEan")?.addEventListener("keydown", e => { if (e.key==="Enter") container.querySelector("#fcEk")?.focus(); });
    container.querySelector("#fcEk")?.addEventListener("keydown",  e => { if (e.key==="Enter") runCheck(container); });
    container.querySelector("#fcScanBtn")?.addEventListener("click", () => openScannerModal());
  }

  // ─── Run Check ────────────────────────────────────────────────────────────
  async function runCheck(container) {
    const ean      = container.querySelector("#fcEan")?.value.trim();
    const ekRaw    = container.querySelector("#fcEk")?.value.trim();
    const ek       = parseFloat(ekRaw);
    const mode     = selectedMode;
    const cat      = container.querySelector("#fcCategory")?.value || "sonstiges";
    const shipIn   = parseFloat(container.querySelector("#fcShipIn")?.value)    || 0;
    const shipOut  = parseFloat(container.querySelector("#fcShipOut")?.value)   || 0;
    const packaging = parseFloat(container.querySelector("#fcPackaging")?.value) || 0;

    if (!ean) { Toast.error("EAN fehlt", "Bitte eine EAN eingeben."); return; }
    if (!ekRaw || isNaN(ek) || ek <= 0) { Toast.error("EK fehlt", "Bitte einen gültigen Einkaufspreis eingeben."); return; }

    const resultEl = container.querySelector("#fcResult");
    resultEl.innerHTML = renderLoading();
    const btn = container.querySelector("#btnCheck");
    if (btn) btn.disabled = true;

    try {
      const { ok, data } = await API.flipcheck(ean, ek, mode, {
        category:     cat,
        shipping_in:  shipIn,
        shipping_out: shipOut,
        vat_mode:     _vatMode,
        ek_mode:      _ekMode,
      });

      if (!ok || !data) throw new Error(data?.detail || "Backend nicht erreichbar");

      // Debug: log price_series availability (remove after confirming works)
      console.log("[Flipcheck] price_series:", data.price_series?.length ?? 0, "points | qty_series:", data.qty_series?.length ?? 0);

      lastResult = data; lastEan = ean; lastEk = ek;
      resultEl.innerHTML = renderResult(data, ean, ek, cat, shipIn, shipOut);

      // Auto-save price history — one point for today's check
      try {
        await Storage.savePrice({ ean, title: data.title || ean, browse_avg: data.browse_avg, browse_median: data.sell_price_median, research_avg: data.sell_price_avg, sales_30d: data.sales_30d });
      } catch {}

      // Save 30-day Research series into history (deduped by day — safe every time)
      if (data.price_series?.length) {
        Storage.savePriceSeries({ ean, title: data.title || ean, price_series: data.price_series, qty_series: data.qty_series || [] });
      }

      // Render inline price chart — pass fresh series directly (no Storage roundtrip needed)
      loadPriceChart(ean, resultEl, data.price_series, data.qty_series);

      resultEl.querySelector("#btnCreateListing")?.addEventListener("click", () => ListingAssistant.open(data, ean, ek));
      resultEl.querySelector("#btnAddToInv")?.addEventListener("click",     () => addToInventory(ean, ek, data));
      resultEl.querySelector("#btnReset")?.addEventListener("click",         () => { resultEl.innerHTML = renderResultPlaceholder(); });

    } catch (err) {
      resultEl.innerHTML = renderError(err.message || "Unbekannter Fehler");
      resultEl.querySelector("#btnReset")?.addEventListener("click", () => { resultEl.innerHTML = renderResultPlaceholder(); });
    } finally {
      if (btn && _el) btn.disabled = false; // guard: only if view still mounted
    }
  }

  async function addToInventory(ean, ek, data) {
    try {
      await Storage.upsertItem({ ean, title: data.title || ean, ek, market: "ebay", status: "IN_STOCK", qty: 1 });
      Toast.success("Hinzugefügt", `${data.title || ean} zum Inventory hinzugefügt.`);
    } catch {
      Toast.error("Fehler", "Konnte nicht zum Inventory hinzugefügt werden.");
    }
  }

  return { mount, unmount };
})();
