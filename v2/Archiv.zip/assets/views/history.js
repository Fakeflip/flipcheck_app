/* Flipcheck v2 — Preishistorie View */
const HistoryView = (() => {
  let _container = null;
  let _histList = [];
  let _selectedEan = null;
  let _chart = null;

  function mount(container) {
    _container = container;
    _selectedEan = null;
    container.innerHTML = renderShell();
    loadList(container);
  }

  function unmount() {
    if (_chart) { try { _chart.destroy(); } catch {} _chart = null; }
    _container = null;
  }

  function renderShell() {
    return `
      <div class="page-header">
        <div class="page-header-left">
          <h1>Preishistorie</h1>
          <p>Preisentwicklung pro Produkt über Zeit verfolgen</p>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:320px 1fr;gap:20px;align-items:start">

        <!-- EAN List -->
        <div class="panel" style="padding:0;overflow:hidden">
          <div style="padding:12px 16px;border-bottom:1px solid var(--border)">
            <input id="histSearch" class="input" type="search" placeholder="EAN oder Titel suchen…" style="font-size:12px;padding:6px 10px" />
          </div>
          <div id="histList" style="max-height:560px;overflow-y:auto">
            <div class="empty-state" style="padding:32px">
              <div class="spinner spinner-sm"></div>
            </div>
          </div>
        </div>

        <!-- Chart + Detail -->
        <div id="histDetail">
          ${renderDetailEmpty()}
        </div>

      </div>
    `;
  }

  function renderDetailEmpty() {
    return `
      <div class="empty-state" style="padding:80px">
        <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
        </svg>
        <p class="empty-title">EAN auswählen</p>
        <p class="empty-sub">Wähle ein Produkt aus der Liste um den Preisverlauf zu sehen.</p>
      </div>
    `;
  }

  async function loadList(container) {
    try {
      _histList = await Storage.listHistory();
    } catch {
      _histList = [];
    }
    renderList(container, _histList);

    container.querySelector("#histSearch")?.addEventListener("input", e => {
      const q = e.target.value.toLowerCase();
      const filtered = _histList.filter(h =>
        h.ean.includes(q) || (h.title||"").toLowerCase().includes(q)
      );
      renderList(container, filtered);
    });
  }

  function renderList(container, items) {
    const listEl = container.querySelector("#histList");
    if (!listEl) return;

    if (items.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state" style="padding:32px">
          <p class="empty-title text-sm">Keine Daten</p>
          <p class="empty-sub" style="font-size:11px">Führe zuerst Flipchecks durch.</p>
        </div>
      `;
      return;
    }

    // Remove previous delegated listener before re-render
    if (listEl._histDelegate) {
      listEl.removeEventListener("click",      listEl._histDelegate);
      listEl.removeEventListener("mouseover",  listEl._histHover);
      listEl.removeEventListener("mouseout",   listEl._histOut);
    }

    listEl.innerHTML = items.map(h => `
      <div class="hist-list-item ${h.ean === _selectedEan ? "active" : ""}" data-ean="${esc(h.ean)}" style="
        padding:10px 16px;
        border-bottom:1px solid var(--border-subtle);
        cursor:pointer;
        transition:background var(--t-fast);
        ${h.ean === _selectedEan ? "background:var(--accent-subtle);" : ""}
      ">
        <div style="font-size:12px;font-weight:600;color:var(--text-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(h.title || h.ean)}</div>
        <div class="row" style="margin-top:3px;gap:8px">
          <span class="text-xs text-muted">${esc(h.ean)}</span>
          <span class="text-xs text-muted">${h.count} Einträge</span>
          ${h.last_price ? `<span class="text-xs text-secondary font-semibold">${fmtEur(h.last_price)}</span>` : ""}
        </div>
      </div>
    `).join("");

    // Event delegation — single listener on container, not per-item
    listEl._histDelegate = e => {
      const item = e.target.closest(".hist-list-item");
      if (item) loadDetail(item.dataset.ean, container);
    };
    listEl._histHover = e => {
      const item = e.target.closest(".hist-list-item");
      if (item && item.dataset.ean !== _selectedEan) item.style.background = "var(--bg-hover)";
    };
    listEl._histOut = e => {
      const item = e.target.closest(".hist-list-item");
      if (item && item.dataset.ean !== _selectedEan) item.style.background = "";
    };
    listEl.addEventListener("click",     listEl._histDelegate);
    listEl.addEventListener("mouseover", listEl._histHover);
    listEl.addEventListener("mouseout",  listEl._histOut);
  }

  async function loadDetail(ean, container) {
    _selectedEan = ean;

    // Update list highlight
    container.querySelectorAll(".hist-list-item").forEach(el => {
      el.classList.toggle("active", el.dataset.ean === ean);
      el.style.background = el.dataset.ean === ean ? "var(--accent-subtle)" : "";
    });

    const detailEl = container.querySelector("#histDetail");
    if (!detailEl) return;
    detailEl.innerHTML = `<div class="empty-state" style="padding:60px"><div class="spinner"></div></div>`;

    if (_chart) { try { _chart.destroy(); } catch {} _chart = null; }

    const data = await Storage.getHistory(ean);

    if (!data.entries || data.entries.length === 0) {
      detailEl.innerHTML = `
        <div class="panel">
          <p class="text-secondary">Keine Preisdaten für ${esc(ean)} gefunden.</p>
          <button class="btn btn-danger btn-sm mt-12" id="btnDeleteHist">Eintrag löschen</button>
        </div>
      `;
      detailEl.querySelector("#btnDeleteHist")?.addEventListener("click", async () => {
        await Storage.deleteHistory(ean);
        _selectedEan = null;
        await loadList(container);
        detailEl.innerHTML = renderDetailEmpty();
        Toast.info("Gelöscht", `Historie für ${ean} wurde entfernt.`);
      });
      return;
    }

    const entries = data.entries.slice(-90); // last 90 entries (series = 31/check)
    // Use research_avg (daily avg sold) first, fall back to browse price
    const prices = entries.map(e => e.research_avg ?? e.browse_median ?? e.browse_avg ?? null).filter(Boolean);
    const trend = calcTrend(prices);

    detailEl.innerHTML = renderDetail(data, entries, trend);
    initChart(entries);

    detailEl.querySelector("#btnDeleteHist")?.addEventListener("click", async () => {
      const ok = await Modal.confirm("Historie löschen", `Alle Preisdaten für "${esc(data.title || ean)}" löschen?`, { confirmLabel: "Löschen", danger: true });
      if (!ok) return;
      await Storage.deleteHistory(ean);
      _selectedEan = null;
      await loadList(container);
      detailEl.innerHTML = renderDetailEmpty();
      Toast.success("Gelöscht");
    });
  }

  function calcTrend(prices) {
    if (prices.length < 2) return { dir: "flat", pct: 0, first: prices[0], last: prices[prices.length-1] };
    const first = prices[0];
    const last = prices[prices.length - 1];
    if (!first) return { dir: "flat", pct: 0, first, last }; // guard: division by zero
    const pct = ((last - first) / first) * 100;
    return { dir: pct > 1.5 ? "up" : pct < -1.5 ? "down" : "flat", pct, first, last };
  }

  function renderDetail(data, entries, trend) {
    const trendIcon = trend.dir === "up"
      ? `<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 12L8 6l3 3 5-5M13 4h3v3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
      : trend.dir === "down"
      ? `<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 4L8 10l3-3 5 5M13 12h3v-3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`
      : `<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 8h12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`;

    const trendClass = trend.dir === "up" ? "trend-up" : trend.dir === "down" ? "trend-down" : "trend-flat";
    // research_avg is daily avg sold price (from series); browse_median is live listing price
    const prices = entries.map(e => e.research_avg ?? e.browse_median ?? e.browse_avg).filter(Boolean);
    const minPrice = prices.length ? Math.min(...prices) : 0;
    const maxPrice = prices.length ? Math.max(...prices) : 0;
    const avgPrice = prices.length ? prices.reduce((a,b) => a+b, 0) / prices.length : 0;
    const lastEntry = entries[entries.length - 1];
    // Sum of daily quantities for "Insgesamt verkauft" over visible period
    const totalQty = entries.reduce((s, e) => s + (e.qty ?? 0), 0);

    return `
      <div class="col gap-16">

        <!-- Header -->
        <div class="panel panel-sm">
          <div class="row-between">
            <div>
              <div style="font-weight:700;font-size:15px;color:var(--text-primary)">${esc(data.title || data.ean)}</div>
              <div class="text-xs text-muted mt-8">${esc(data.ean)} · ${entries.length} Messpunkte</div>
            </div>
            <div class="col" style="align-items:flex-end;gap:6px">
              <div class="${trendClass} row gap-4 font-bold" style="font-size:14px">
                ${trendIcon}
                ${trend.dir === "flat" ? "Stabil" : `${trend.pct > 0 ? "+" : ""}${trend.pct.toFixed(1)}%`}
              </div>
              <div class="text-xs text-muted">seit erstem Eintrag</div>
            </div>
          </div>
        </div>

        <!-- KPIs -->
        <div class="grid-4">
          <div class="kpi-card">
            <div class="kpi-label">Aktuell (Ø VK)</div>
            <div class="kpi-value">${fmtEur(lastEntry?.research_avg ?? lastEntry?.browse_median ?? lastEntry?.browse_avg)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">Minimum</div>
            <div class="kpi-value text-green">${fmtEur(minPrice)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">Maximum</div>
            <div class="kpi-value text-red">${fmtEur(maxPrice)}</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">Ø Preis / Verkäufe</div>
            <div class="kpi-value">${fmtEur(avgPrice)} <span class="text-muted" style="font-size:11px;font-weight:400">· ${totalQty > 0 ? totalQty+" Stk." : "—"}</span></div>
          </div>
        </div>

        <!-- Chart -->
        <div class="panel">
          <div class="row-between mb-8">
            <h3 class="panel-title" style="margin-bottom:0">Preisverlauf</h3>
            <span class="badge badge-gray">letzte ${entries.length} Datenpunkte</span>
          </div>
          <div class="chart-container">
            <canvas id="histChart" height="200"></canvas>
          </div>
        </div>

        <!-- Table -->
        <div class="panel" style="padding:0;overflow:hidden">
          <div style="padding:12px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
            <span class="panel-title" style="margin:0">Datenpunkte</span>
            <button class="btn btn-danger btn-sm" id="btnDeleteHist">Löschen</button>
          </div>
          <div class="table-wrap" style="max-height:240px;overflow-y:auto">
            <table class="table">
              <thead>
                <tr>
                  <th>Datum</th>
                  <th class="col-right">Ø Verkaufspreis</th>
                  <th class="col-right">Browse-Preis</th>
                  <th class="col-right">Stk. verkauft</th>
                  <th class="col-right">Quelle</th>
                </tr>
              </thead>
              <tbody>
                ${[...entries].reverse().map(e => `
                  <tr>
                    <td class="text-sm">${fmtDate(e.ts)}</td>
                    <td class="col-right col-num">${fmtEur(e.research_avg)}</td>
                    <td class="col-right col-num text-muted">${fmtEur(e.browse_median ?? e.browse_avg)}</td>
                    <td class="col-right col-num">${e.qty != null ? e.qty : (e.sales_30d != null ? e.sales_30d : "—")}</td>
                    <td class="col-right"><span class="badge ${e.from_series ? "badge-gray" : "badge-green"}" style="font-size:9px">${e.from_series ? "Research" : "Live"}</span></td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    `;
  }

  function initChart(entries) {
    const ctx = document.getElementById("histChart");
    if (!ctx) return;

    const hasQty = entries.some(e => e.qty != null);

    const labels       = entries.map(e => fmtDate(e.ts));
    const researchData = entries.map(e => e.research_avg ?? null);
    const browseData   = entries.map(e => e.browse_median ?? e.browse_avg ?? null);
    const qtyData      = entries.map(e => e.qty ?? 0);

    _chart = new Chart(ctx, {
      type: "bar",
      data: {
        labels,
        datasets: [
          // Qty bars — background
          ...(hasQty ? [{
            type: "bar",
            label: "Verkäufe/Tag",
            data: qtyData,
            backgroundColor: "rgba(99,102,241,0.12)",
            borderColor: "transparent",
            borderWidth: 0,
            yAxisID: "yQty",
            order: 3,
          }] : []),
          // Research / avg sold price line
          {
            type: "line",
            label: "Ø Verkaufspreis",
            data: researchData,
            borderColor: "#6366F1",
            backgroundColor: "rgba(99,102,241,0.08)",
            borderWidth: 2,
            fill: !hasQty,
            tension: 0.3,
            pointRadius: entries.length <= 14 ? 3 : 1,
            pointHoverRadius: 5,
            pointBackgroundColor: "#6366F1",
            pointBorderColor: "transparent",
            spanGaps: true,
            yAxisID: "yPrice",
            order: 1,
          },
          // Browse price (secondary line — dashed, only when both sources present)
          ...(browseData.some(v => v != null) ? [{
            type: "line",
            label: "Browse-Preis",
            data: browseData,
            borderColor: "#10B981",
            borderWidth: 1.5,
            fill: false,
            tension: 0.3,
            pointRadius: entries.length <= 14 ? 2 : 0,
            pointHoverRadius: 4,
            pointBackgroundColor: "#10B981",
            pointBorderColor: "transparent",
            borderDash: [4, 3],
            spanGaps: true,
            yAxisID: "yPrice",
            order: 2,
          }] : []),
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        interaction: { intersect: false, mode: "index" },
        plugins: {
          legend: {
            position: "top",
            align: "end",
            labels: { font: { size: 11, family: "Inter, sans-serif" }, color: "#94A3B8", boxWidth: 10, boxHeight: 2, padding: 12 },
          },
          tooltip: {
            backgroundColor: "#16161F",
            borderColor: "#2E2E42",
            borderWidth: 1,
            titleColor: "#F1F5F9",
            bodyColor: "#94A3B8",
            callbacks: {
              label: c => c.dataset.label === "Verkäufe/Tag"
                ? ` Verkäufe: ${c.parsed.y} Stk.`
                : ` ${c.dataset.label}: ${fmtEur(c.parsed.y)}`,
            },
          },
        },
        scales: {
          x: {
            grid: { color: "rgba(30,30,46,0.6)", drawBorder: false },
            ticks: { font: { size: 10 }, color: "#475569", maxTicksLimit: 10, maxRotation: 0 },
          },
          yPrice: {
            position: "left",
            grid: { color: "rgba(30,30,46,0.6)", drawBorder: false },
            ticks: { font: { size: 10 }, color: "#475569", callback: v => fmtEur(v) },
          },
          ...(hasQty ? {
            yQty: {
              position: "right",
              grid: { drawOnChartArea: false },
              ticks: { font: { size: 10 }, color: "#475569", maxTicksLimit: 4 },
              title: { display: true, text: "Stk.", color: "#475569", font: { size: 9 } },
            },
          } : {}),
        },
      },
    });
  }

  return { mount, unmount };
})();
