/* Flipcheck v2 — Konkurrenz-Monitor View */
const CompetitionView = (() => {
  let _container      = null;
  let _tab            = "sellers";
  let _sellers        = [];
  let _sellerSelected = null;
  let _inventory      = [];
  let _invSelected    = null;
  let _debounce       = null;   // module-scope so unmount() can clear it
  const _compCache    = new Map();  // itemId → { total, items, fetchedAt }

  // ── Lifecycle ────────────────────────────────────────────────────────────
  function mount(container) {
    _container      = container;
    _tab            = "sellers";
    _sellerSelected = null;
    _invSelected    = null;
    container.innerHTML = renderShell();
    init(container);
  }

  function unmount() {
    if (_debounce) { clearTimeout(_debounce); _debounce = null; }
    _container = null;
  }

  // ── Shell ────────────────────────────────────────────────────────────────
  function renderShell() {
    return `
      <div class="page-header">
        <div class="page-header-left">
          <h1>Konkurrenz-Monitor</h1>
          <p>Verkäufer beobachten · Marktposition deiner Produkte checken</p>
        </div>
      </div>

      <div class="comp-tabs mb-16">
        <button class="comp-tab active" data-tab="sellers">
          <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
            <circle cx="8" cy="5.5" r="3" stroke="currentColor" stroke-width="1.5"/>
            <path d="M2 14c0-3.31 2.69-6 6-6s6 2.69 6 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          Verkäufer
        </button>
        <button class="comp-tab" data-tab="inventory">
          <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
            <rect x="1" y="5" width="14" height="10" rx="1.5" stroke="currentColor" stroke-width="1.5"/>
            <path d="M5 5V3.5A3 3 0 0 1 11 3.5V5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <path d="M5.5 9.5h5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          </svg>
          Mein Inventory
        </button>
      </div>

      <div class="comp-split" id="compContent">
        ${renderSellersPanel()}
      </div>
    `;
  }

  async function init(container) {
    _sellers = await Storage.listSellers();
    rerenderSellerLeft();
    bindTabs(container);
    bindSellerForm(container);
    bindSellerList(container);
  }

  // ── Tab logic ────────────────────────────────────────────────────────────
  function bindTabs(container) {
    container.querySelector(".comp-tabs")?.addEventListener("click", async e => {
      const btn = e.target.closest(".comp-tab");
      if (!btn || btn.dataset.tab === _tab) return;
      _tab = btn.dataset.tab;
      container.querySelectorAll(".comp-tab").forEach(b => b.classList.toggle("active", b.dataset.tab === _tab));
      const content = container.querySelector("#compContent");
      if (!content) return;
      if (_tab === "sellers") {
        content.innerHTML = renderSellersPanel();
        rerenderSellerLeft();
        bindSellerForm(container);
        bindSellerList(container);
      } else {
        content.innerHTML = renderLoadingFull("Inventory wird geladen…");
        _inventory = await Storage.listInventory();
        content.innerHTML = renderInventoryPanel();
        bindInvList(container);
      }
    });
  }

  // ──────────────────────────────────────────────────────────────────────────
  // SELLERS TAB
  // ──────────────────────────────────────────────────────────────────────────
  function renderSellersPanel() {
    return `
      <div class="comp-left" id="sellerLeft">
        <div class="comp-add-wrap">
          <input class="input" id="sellerInput" placeholder="eBay Username…" style="flex:1;min-width:0"/>
          <button class="btn btn-primary btn-sm" id="btnAddSeller" style="white-space:nowrap">+ Hinzufügen</button>
        </div>
        <div id="sellerList" class="comp-list"></div>
      </div>
      <div class="comp-right" id="compRight">${renderRightEmpty("Verkäufer auswählen", "Links einen Verkäufer auswählen oder per Username hinzufügen.")}</div>
    `;
  }

  function renderSellerListItems() {
    if (!_sellers.length) return `<div class="comp-list-empty">Noch keine Verkäufer.<br>Username oben eingeben.</div>`;
    return _sellers.map(s => {
      const fbStr = s.feedback_score != null
        ? `${Number(s.feedback_score).toLocaleString("de-DE")} Bew.`
        : null;
      const listStr = s.listing_count != null ? `${s.listing_count} Listings` : null;
      const sub = [listStr, fbStr].filter(Boolean).join(" · ") || "noch nicht geladen";
      return `
        <div class="comp-list-item ${_sellerSelected === s.username ? "active" : ""}" data-seller="${esc(s.username)}">
          <div class="comp-avatar">${(s.username[0] || "?").toUpperCase()}</div>
          <div style="flex:1;min-width:0">
            <div class="comp-item-name">@${esc(s.username)}</div>
            <div class="text-xs text-muted">
              ${sub}${s.last_checked ? ` · vor ${timeSince(s.last_checked)}` : ""}
            </div>
          </div>
          <button class="comp-del-btn" data-remove="${esc(s.username)}" title="Entfernen">
            <svg width="11" height="11" viewBox="0 0 16 16" fill="none"><path d="M2 2l12 12M14 2L2 14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
          </button>
        </div>
      `;
    }).join("");
  }

  function rerenderSellerLeft() {
    const list = _container?.querySelector("#sellerList");
    if (list) list.innerHTML = renderSellerListItems();
    bindSellerList(_container);
  }

  function bindSellerForm(container) {
    const btn   = container?.querySelector("#btnAddSeller");
    const input = container?.querySelector("#sellerInput");
    if (!btn || !input) return;
    const doAdd = async () => {
      const username = input.value.trim().replace(/^@/, "");
      if (!username) return;
      input.value = "";
      btn.disabled = true;
      try {
        _sellers = await Storage.addSeller(username);
        rerenderSellerLeft();
        await loadSellerListings(username);
      } catch { Toast.error("Fehler", "Konnte nicht hinzugefügt werden."); }
      finally  { btn.disabled = false; }
    };
    btn.addEventListener("click", doAdd);
    input.addEventListener("keydown", e => { if (e.key === "Enter") doAdd(); });
  }

  function bindSellerList(container) {
    if (!container) return;
    container.querySelectorAll("[data-seller]").forEach(el => {
      el.addEventListener("click", e => {
        if (e.target.closest("[data-remove]")) return;
        loadSellerListings(el.dataset.seller);
      });
    });
    container.querySelectorAll("[data-remove]").forEach(btn => {
      btn.addEventListener("click", async e => {
        e.stopPropagation();
        const u = btn.dataset.remove;
        _sellers = await Storage.removeSeller(u);
        if (_sellerSelected === u) {
          _sellerSelected = null;
          const right = _container?.querySelector("#compRight");
          if (right) right.innerHTML = renderRightEmpty("Verkäufer auswählen", "Links einen Verkäufer auswählen.");
        }
        rerenderSellerLeft();
      });
    });
  }

  async function loadSellerListings(username, q = "") {
    _sellerSelected = username;
    rerenderSellerLeft();
    const right = _container?.querySelector("#compRight");
    if (right) right.innerHTML = renderRightLoading(`@${username} wird geladen…`);
    try {
      const { ok, data } = await API.sellerListings(username, 100, q);
      if (!ok || !data?.ok) throw new Error(data?.error || "API-Fehler");
      const items = data.items || [];
      const feedbackScore = items[0]?.seller_feedback ?? null;
      const feedbackPct   = items[0]?.seller_pct   ?? null;
      // Only update listing count + feedback when no search filter is active
      if (!q) {
        await Storage.updateSellerCount(username, data.total, feedbackScore, feedbackPct);
        const s = _sellers.find(x => x.username === username);
        if (s) {
          s.listing_count  = data.total;
          s.last_checked   = new Date().toISOString();
          s.feedback_score = feedbackScore;
          s.feedback_pct   = feedbackPct;
        }
        rerenderSellerLeft();
      }
      if (right) right.innerHTML = renderSellerListings(username, data.total, items, q, feedbackScore, feedbackPct);
      bindRightRefresh();
    } catch (err) {
      if (right) right.innerHTML = renderRightError(err.message);
    }
  }

  function renderSellerListings(username, total, items, activeQ = "", feedbackScore = null, feedbackPct = null) {
    const rows = items.map(it => `
      <tr>
        <td>
          <div class="row gap-8">
            ${it.image_url ? `<img src="${esc(it.image_url)}" style="width:30px;height:30px;object-fit:contain;border-radius:4px;flex-shrink:0" loading="lazy">` : ""}
            <span class="comp-listing-title" title="${esc(it.title)}">${esc(it.title)}</span>
          </div>
        </td>
        <td class="text-right font-bold" style="font-variant-numeric:tabular-nums;white-space:nowrap">${fmtEur(it.price)}</td>
        <td class="text-muted text-sm text-right" style="white-space:nowrap">${it.shipping != null ? `+${fmtEur(it.shipping)}` : "—"}</td>
        <td><span class="badge badge-muted" style="font-size:10px;white-space:nowrap">${esc(it.condition || "—")}</span></td>
        <td style="text-align:right">${it.item_url ? `<a href="${esc(it.item_url)}" class="btn btn-ghost btn-sm" target="_blank" style="padding:2px 8px;font-size:10px">eBay →</a>` : ""}</td>
      </tr>
    `).join("");

    const totalLabel = activeQ
      ? `${total} Treffer für „${esc(activeQ)}"`
      : `${total} Listings · gerade abgerufen`;

    // Build seller stats pill for header
    const fbParts = [];
    if (feedbackScore != null) fbParts.push(`<span class="comp-stat-pill">⭐ ${Number(feedbackScore).toLocaleString("de-DE")} Bew.</span>`);
    if (feedbackPct   != null) fbParts.push(`<span class="comp-stat-pill">${parseFloat(feedbackPct).toFixed(1)}% positiv</span>`);
    const statsHtml = fbParts.length ? `<div class="row gap-6" style="margin-top:4px">${fbParts.join("")}</div>` : "";

    return `
      <div class="comp-right-hdr">
        <div>
          <div class="font-semibold" style="font-size:14px">@${esc(username)}</div>
          <div class="text-xs text-muted">${totalLabel}</div>
          ${statsHtml}
        </div>
        <div class="row gap-8">
          <div class="comp-search-wrap">
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;color:var(--text-muted)">
              <circle cx="6.5" cy="6.5" r="4.5" stroke="currentColor" stroke-width="1.5"/>
              <path d="M10.5 10.5L14.5 14.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
            <input class="comp-search-input" id="sellerSearchInput" placeholder="Listings durchsuchen…"
              value="${esc(activeQ)}" data-seller="${esc(username)}"/>
          </div>
          <button class="btn btn-secondary btn-sm" data-refresh-seller="${esc(username)}">
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M13 8A5 5 0 1 1 3.07 5.65M3 2v4h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            Alle laden
          </button>
        </div>
      </div>
      <div class="comp-table-wrap">
        <table class="comp-table">
          <thead><tr>
            <th>Titel</th>
            <th class="text-right">Preis</th>
            <th class="text-right">Versand</th>
            <th>Zustand</th>
            <th></th>
          </tr></thead>
          <tbody>${rows || `<tr><td colspan="5" class="text-center text-muted" style="padding:32px">Keine Listings gefunden.</td></tr>`}</tbody>
        </table>
      </div>
    `;
  }

  // ──────────────────────────────────────────────────────────────────────────
  // INVENTORY TAB
  // ──────────────────────────────────────────────────────────────────────────
  function renderInventoryPanel() {
    const active = _inventory.filter(i => ["IN_STOCK", "LISTED", "LISTING_PENDING"].includes(i.status));
    const leftRows = active.length
      ? active.map(item => {
          const cache = _compCache.get(item.id);
          const statusHtml = cache ? renderInvStatusChip(item, cache) : "";
          return `
            <div class="comp-list-item ${_invSelected?.id === item.id ? "active" : ""}" data-inv="${esc(item.id)}">
              <div style="flex:1;min-width:0">
                <div class="comp-item-name" style="font-size:12px">${esc((item.title || item.ean || "—").slice(0, 38))}</div>
                <div class="text-xs text-muted">${esc(item.ean || "keine EAN")}</div>
                ${statusHtml}
              </div>
              <button class="btn btn-ghost btn-sm comp-check-btn" style="font-size:10px;padding:2px 7px;flex-shrink:0" data-check="${esc(item.id)}">Check</button>
            </div>
          `;
        }).join("")
      : `<div class="comp-list-empty">Keine aktiven Items im Inventory.</div>`;

    return `
      <div class="comp-left">
        <div class="row-between mb-10">
          <span class="text-xs text-muted font-semibold">${active.length} aktive Produkte</span>
          <button class="btn btn-secondary btn-sm" id="btnCheckAll" style="font-size:11px">Alle prüfen</button>
        </div>
        <div class="comp-list" id="invList">${leftRows}</div>
      </div>
      <div class="comp-right" id="compRight">${renderRightEmpty("Produkt wählen", "Links ein Inventory-Item wählen um die Konkurrenz zu sehen.")}</div>
    `;
  }

  function renderInvStatusChip(item, cache) {
    const { total, items } = cache;
    const myPrice = item.sell_price || null;
    if (!myPrice) return `<div class="comp-status-chip comp-status-neutral">${total} Anbieter</div>`;
    const cheapest = items[0]?.total_price;
    if (cheapest && cheapest < myPrice - 0.01)
      return `<div class="comp-status-chip comp-status-danger">⚠ unterboten ${fmtEur(cheapest)}</div>`;
    const rank = items.filter(i => i.total_price < myPrice).length + 1;
    if (rank === 1)
      return `<div class="comp-status-chip comp-status-good">✓ günstigster</div>`;
    return `<div class="comp-status-chip comp-status-neutral">#${rank} von ${total}</div>`;
  }

  function bindInvList(container) {
    if (!container) return;
    container.querySelectorAll("[data-inv]").forEach(el => {
      el.addEventListener("click", e => {
        if (e.target.closest("[data-check]")) return;
        const item = _inventory.find(i => i.id === el.dataset.inv);
        if (item) loadInvCompetition(item);
      });
    });
    container.querySelectorAll("[data-check]").forEach(btn => {
      btn.addEventListener("click", e => {
        e.stopPropagation();
        const item = _inventory.find(i => i.id === btn.dataset.check);
        if (item) loadInvCompetition(item);
      });
    });
    container.querySelector("#btnCheckAll")?.addEventListener("click", checkAllInventory);
  }

  async function checkAllInventory() {
    const active = _inventory.filter(i => ["IN_STOCK","LISTED","LISTING_PENDING"].includes(i.status) && i.ean);
    if (!active.length) { Toast.info("Keine EANs", "Keine aktiven Items mit EAN."); return; }
    Toast.info("Prüfe alle…", `${active.length} Items werden geprüft.`);
    for (const item of active) {
      await loadInvCompetition(item, true);
      await new Promise(r => setTimeout(r, 400));
    }
    Toast.success("Fertig", `${active.length} Items geprüft.`);
    rerenderInvLeft();
  }

  async function loadInvCompetition(item, silent = false) {
    if (!item.ean) { if (!silent) Toast.warning("EAN fehlt", "Dieses Item hat keine EAN hinterlegt."); return; }
    _invSelected = item;
    rerenderInvLeft();
    const right = _container?.querySelector("#compRight");
    if (right && !silent) right.innerHTML = renderRightLoading(`Konkurrenz für "${(item.title || item.ean).slice(0, 30)}" laden…`);
    try {
      const { ok, data } = await API.eanCompetition(item.ean, 50);
      if (!ok || !data?.ok) throw new Error(data?.error || "API-Fehler");
      const items = data.items || [];
      _compCache.set(item.id, { total: data.total, items, fetchedAt: Date.now() });
      rerenderInvLeft();
      if (right && !silent) { right.innerHTML = renderInvCompetition(item, data.total, items); bindRightRefresh(); }
    } catch (err) {
      if (right && !silent) right.innerHTML = renderRightError(err.message);
    }
  }

  function rerenderInvLeft() {
    const list = _container?.querySelector("#invList");
    if (!list) return;
    const active = _inventory.filter(i => ["IN_STOCK","LISTED","LISTING_PENDING"].includes(i.status));
    list.innerHTML = active.length
      ? active.map(item => {
          const cache = _compCache.get(item.id);
          const statusHtml = cache ? renderInvStatusChip(item, cache) : "";
          return `
            <div class="comp-list-item ${_invSelected?.id === item.id ? "active" : ""}" data-inv="${esc(item.id)}">
              <div style="flex:1;min-width:0">
                <div class="comp-item-name" style="font-size:12px">${esc((item.title || item.ean || "—").slice(0, 38))}</div>
                <div class="text-xs text-muted">${esc(item.ean || "keine EAN")}</div>
                ${statusHtml}
              </div>
              <button class="btn btn-ghost btn-sm comp-check-btn" style="font-size:10px;padding:2px 7px;flex-shrink:0" data-check="${esc(item.id)}">Check</button>
            </div>
          `;
        }).join("")
      : `<div class="comp-list-empty">Keine aktiven Items.</div>`;
    bindInvList(_container);
  }

  function renderInvCompetition(item, total, items) {
    const myPrice  = item.sell_price || null;
    const cheapest = items[0]?.total_price ?? null;
    const highest  = items[items.length - 1]?.total_price ?? null;
    const myRank   = myPrice != null
      ? items.filter(i => (i.total_price || 0) < myPrice).length + 1
      : null;

    // Position banner
    let banner = "";
    if (myPrice != null && cheapest != null) {
      if (cheapest < myPrice - 0.01) {
        banner = `<div class="comp-banner comp-banner-danger">
          ⚠️  Du wirst unterboten — günstigster Konkurrent: <strong>${fmtEur(cheapest)}</strong>
          (dein VK: ${fmtEur(myPrice)}, Differenz: ${fmtEur(myPrice - cheapest)})
        </div>`;
      } else if (myRank === 1) {
        banner = `<div class="comp-banner comp-banner-success">
          ✅  Du bist der günstigste Anbieter (${fmtEur(myPrice)}) — ${total - 1} teurer als du.
        </div>`;
      } else {
        banner = `<div class="comp-banner comp-banner-neutral">
          📊  Du bist Rang <strong>#${myRank}</strong> von ${total} Anbietern (${fmtEur(myPrice)}).
        </div>`;
      }
    }

    // KPI bar
    const kpiBar = `
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px">
        <div class="ds-kpi"><div class="ds-kpi-lbl">Günstigster</div><div class="ds-kpi-val">${fmtEur(cheapest)}</div></div>
        <div class="ds-kpi"><div class="ds-kpi-lbl">Teuerster</div><div class="ds-kpi-val">${fmtEur(highest)}</div></div>
        <div class="ds-kpi"><div class="ds-kpi-lbl">${myRank != null ? "Mein Rang" : "Anbieter"}</div>
          <div class="ds-kpi-val">${myRank != null ? `#${myRank} / ${total}` : total}</div></div>
        <div class="ds-kpi"><div class="ds-kpi-lbl">Mein VK</div>
          <div class="ds-kpi-val" style="color:${myPrice != null ? "var(--text-primary)" : "var(--text-muted)"}">${myPrice != null ? fmtEur(myPrice) : "—"}</div></div>
      </div>
    `;

    // Table rows — mark cheapest and "me" rows
    const rows = items.map((it, idx) => {
      const isCheapest = idx === 0;
      const isMe = myPrice != null && Math.abs((it.total_price || 0) - myPrice) < 0.02;
      const rowClass = isMe ? "comp-row-me" : isCheapest ? "comp-row-cheapest" : "";
      return `
        <tr class="${rowClass}">
          <td class="text-xs font-semibold" style="white-space:nowrap">
            ${isMe ? `<span class="badge badge-blue" style="font-size:9px;margin-right:4px">ich</span>` : ""}
            ${esc(it.seller_id || "—")}
          </td>
          <td class="text-right font-bold" style="font-variant-numeric:tabular-nums;white-space:nowrap">${fmtEur(it.price)}</td>
          <td class="text-muted text-right text-sm" style="white-space:nowrap">${it.shipping != null ? `+${fmtEur(it.shipping)}` : "inkl."}</td>
          <td class="text-right font-bold" style="font-variant-numeric:tabular-nums;white-space:nowrap;color:${isCheapest && !isMe ? "var(--red)" : "var(--text-primary)"}">${fmtEur(it.total_price)}</td>
          <td><span class="badge badge-muted" style="font-size:9px">${esc(it.condition || "—")}</span></td>
          <td class="text-xs" style="white-space:nowrap">
            ${it.seller_feedback != null
              ? `<span class="font-semibold" style="color:var(--text-secondary)">${Number(it.seller_feedback).toLocaleString("de-DE")}</span>`
              : ""}
            ${it.seller_pct
              ? `<span class="text-muted"> ${parseFloat(it.seller_pct).toFixed(1)}%</span>`
              : it.seller_feedback == null ? `<span class="text-muted">—</span>` : ""}
          </td>
          <td style="text-align:right">${it.item_url ? `<a href="${esc(it.item_url)}" class="btn btn-ghost btn-sm" target="_blank" style="padding:2px 8px;font-size:10px">eBay →</a>` : ""}</td>
        </tr>
      `;
    }).join("");

    return `
      <div class="comp-right-hdr">
        <div>
          <div class="font-semibold" style="font-size:14px">${esc((item.title || item.ean || "—").slice(0, 60))}</div>
          <div class="text-xs text-muted">EAN: ${esc(item.ean || "—")} · ${total} Angebote · gerade abgerufen</div>
        </div>
        <button class="btn btn-secondary btn-sm" data-refresh-inv="${esc(item.id)}">
          <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M13 8A5 5 0 1 1 3.07 5.65M3 2v4h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
          Aktualisieren
        </button>
      </div>
      ${banner}
      ${kpiBar}
      <div class="comp-table-wrap">
        <table class="comp-table">
          <thead><tr>
            <th>Verkäufer</th>
            <th class="text-right">Preis</th>
            <th class="text-right">Versand</th>
            <th class="text-right">Gesamt</th>
            <th>Zustand</th>
            <th>Bewertungen</th>
            <th></th>
          </tr></thead>
          <tbody>${rows || `<tr><td colspan="7" class="text-center text-muted" style="padding:32px">Keine Angebote gefunden.</td></tr>`}</tbody>
        </table>
      </div>
    `;
  }

  // ── Shared right-panel helpers ───────────────────────────────────────────
  function renderRightEmpty(title, sub) {
    return `
      <div class="empty-state" style="padding:80px 40px">
        <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2">
          <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
        </svg>
        <p class="empty-title">${esc(title)}</p>
        <p class="empty-sub">${esc(sub)}</p>
      </div>
    `;
  }

  function renderRightLoading(text) {
    return `
      <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:80px;gap:14px">
        <div class="spinner"></div>
        <p class="text-secondary text-sm">${esc(text)}</p>
      </div>
    `;
  }

  function renderRightError(msg) {
    return `
      <div class="empty-state" style="padding:60px">
        <p class="empty-title" style="color:var(--red)">Fehler</p>
        <p class="empty-sub">${esc(msg)}</p>
      </div>
    `;
  }

  function renderLoadingFull(text) {
    return `
      <div style="display:flex;align-items:center;justify-content:center;padding:120px;gap:14px;flex-direction:column">
        <div class="spinner"></div>
        <p class="text-secondary text-sm">${esc(text)}</p>
      </div>
    `;
  }

  function bindRightRefresh() {
    const c = _container;

    // Seller: "Alle laden" button — clears search, loads all listings
    c?.querySelector("[data-refresh-seller]")?.addEventListener("click", e => {
      const username = e.currentTarget.dataset.refreshSeller;
      const inp = c.querySelector("#sellerSearchInput");
      if (inp) inp.value = "";
      loadSellerListings(username, "");
    });

    // Seller: search input — search within seller on Enter or after 600ms debounce
    const searchInp = c?.querySelector("#sellerSearchInput");
    if (searchInp) {
      const doSearch = () => {
        const q = searchInp.value.trim();
        const username = searchInp.dataset.seller;
        loadSellerListings(username, q);
      };
      searchInp.addEventListener("keydown", e => {
        if (e.key === "Enter") { clearTimeout(_debounce); doSearch(); }
      });
      searchInp.addEventListener("input", () => {
        clearTimeout(_debounce);
        _debounce = setTimeout(doSearch, 650);
      });
    }

    // Inventory: refresh button
    c?.querySelector("[data-refresh-inv]")?.addEventListener("click", e => {
      const item = _inventory.find(i => i.id === e.currentTarget.dataset.refreshInv);
      if (item) loadInvCompetition(item);
    });
  }

  // ── Utility ──────────────────────────────────────────────────────────────
  function timeSince(isoStr) {
    const secs = Math.floor((Date.now() - new Date(isoStr).getTime()) / 1000);
    if (secs < 60)   return "gerade eben";
    if (secs < 3600) return `${Math.floor(secs / 60)} Min.`;
    if (secs < 86400) return `${Math.floor(secs / 3600)} Std.`;
    return `${Math.floor(secs / 86400)} Tagen`;
  }

  return { mount, unmount };
})();
