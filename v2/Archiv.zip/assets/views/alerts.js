/* Flipcheck v2 — Preisalarm View */
const AlertsView = (() => {

  let _el = null;
  let _alerts = [];

  // ── Mount ──────────────────────────────────────────────────────────────────
  async function mount(el) {
    _el = el;
    _el.innerHTML = `
      <div class="alerts-shell">

        <!-- Left: Alert-Liste -->
        <div class="alerts-left">
          <div class="alerts-left-header">
            <span class="alerts-left-title">Aktive Alarme</span>
            <button class="btn btn-ghost btn-sm" id="alRefresh" title="Jetzt prüfen">
              <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
                <path d="M13.5 8A5.5 5.5 0 1 1 8 2.5c1.8 0 3.4.86 4.4 2.2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                <path d="M13.5 2.5v3h-3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
              Jetzt prüfen
            </button>
          </div>
          <div id="alertsList" class="alerts-list">
            <div class="alerts-loading">Lade Alarme…</div>
          </div>
        </div>

        <!-- Right: Neuer Alarm + Info -->
        <div class="alerts-right">
          <div class="alerts-card">
            <div class="alerts-card-title">Neuer Preisalarm</div>

            <div class="la-field">
              <label class="input-label">EAN / GTIN</label>
              <input id="alEan" class="input" type="text" placeholder="z.B. 4010884506594" maxlength="20"/>
            </div>

            <div class="la-field">
              <label class="input-label">Zielpreis (Benachrichtigung wenn ≤)</label>
              <div class="input-prefix-wrap">
                <span class="prefix">€</span>
                <input id="alTarget" class="input" type="number" step="0.01" min="0" placeholder="0.00"/>
              </div>
            </div>

            <div class="la-field">
              <label class="input-label">Bezeichnung (optional)</label>
              <input id="alTitle" class="input" type="text" placeholder="z.B. Nintendo Switch Lite"/>
            </div>

            <button class="btn btn-primary btn-sm" id="alAdd" style="width:100%;margin-top:4px">
              <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
                <path d="M8 2v12M2 8h12" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
              </svg>
              Alarm hinzufügen
            </button>
          </div>

          <div class="alerts-card alerts-info-card" style="margin-top:12px">
            <div class="alerts-card-title">So funktioniert's</div>
            <ul class="alerts-info-list">
              <li>EAN eingeben + Zielpreis festlegen</li>
              <li>Flipcheck prüft alle <strong>15 Minuten</strong> automatisch</li>
              <li>Sobald der eBay-Marktpreis deinen Zielpreis unterschreitet → Desktop-Benachrichtigung</li>
              <li>Alarm kann nach Auslösung zurückgesetzt oder gelöscht werden</li>
            </ul>
          </div>

          <div class="alerts-card" id="alStats" style="margin-top:12px;display:none">
            <div class="alerts-card-title">Status</div>
            <div id="alStatsBody" class="alerts-stats-grid"></div>
          </div>
        </div>

      </div>
    `;

    await loadAlerts();
    bindEvents();
  }

  // ── Unmount ────────────────────────────────────────────────────────────────
  function unmount() {
    _el = null;
  }

  // ── Load & render list ─────────────────────────────────────────────────────
  async function loadAlerts() {
    _alerts = await Storage.listAlerts();
    renderList();
    renderStats();
  }

  function renderList() {
    const container = _el?.querySelector("#alertsList");
    if (!container) return;

    if (!_alerts.length) {
      container.innerHTML = `
        <div class="alerts-empty">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="1.2">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
          </svg>
          <p>Noch keine Alarme</p>
          <span>Füge einen EAN-Zielpreis hinzu</span>
        </div>
      `;
      return;
    }

    container.innerHTML = _alerts.map(a => renderAlertRow(a)).join("");

    // Bind row buttons
    container.querySelectorAll(".al-row-del").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.closest("[data-alert-id]")?.dataset.alertId;
        if (!id) return;
        const ok = await Modal.confirm("Alarm löschen", "Diesen Preisalarm wirklich entfernen?", { confirmLabel: "Löschen", danger: true });
        if (ok) {
          _alerts = await Storage.removeAlert(id);
          renderList();
          renderStats();
        }
      });
    });

    container.querySelectorAll(".al-row-reset").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.closest("[data-alert-id]")?.dataset.alertId;
        if (!id) return;
        _alerts = await Storage.resetAlert(id);
        renderList();
        Toast.info("Zurückgesetzt", "Alarm ist wieder aktiv.");
      });
    });

    container.querySelectorAll(".al-row-toggle").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.closest("[data-alert-id]")?.dataset.alertId;
        if (!id) return;
        const alert = _alerts.find(a => a.id === id);
        if (!alert) return;
        _alerts = await Storage.updateAlert({ id, active: !alert.active });
        renderList();
      });
    });

    // Trigger history expand/collapse
    container.querySelectorAll(".al-history-toggle").forEach(btn => {
      btn.addEventListener("click", () => {
        const id  = btn.dataset.histId;
        const list = document.getElementById(`al-hist-${id}`);
        if (!list) return;
        const open = list.classList.toggle("open");
        btn.querySelector(".al-hist-arrow").textContent = open ? "▼" : "▶";
      });
    });
  }

  function renderAlertRow(a) {
    const triggered  = a.triggered;
    const active     = a.active;
    const lastPrice  = a.last_price != null ? fmtEur(a.last_price) : "—";
    const lastCheck  = a.last_checked ? fmtTime(a.last_checked) : "Noch nie";
    const diffPct    = a.last_price && a.target_price
      ? ((a.last_price - a.target_price) / a.target_price * 100)
      : null;

    let statusChip = "";
    if (triggered) {
      statusChip = `<span class="al-chip al-chip-triggered">Ausgelöst</span>`;
    } else if (!active) {
      statusChip = `<span class="al-chip al-chip-paused">Pausiert</span>`;
    } else {
      statusChip = `<span class="al-chip al-chip-active">Aktiv</span>`;
    }

    let priceCol = `<span class="al-price-now">${lastPrice}</span>`;
    if (diffPct !== null) {
      const color = diffPct <= 0 ? "var(--green)" : "var(--text-muted)";
      priceCol += ` <span style="font-size:10px;color:${color}">${diffPct >= 0 ? "+" : ""}${diffPct.toFixed(1)}%</span>`;
    }

    const toggleTitle = active ? "Pausieren" : "Aktivieren";
    const toggleIcon  = active
      ? `<path d="M6 4h1.5v8H6zM8.5 4H10v8H8.5z" fill="currentColor"/>`
      : `<path d="M5 3.5l10 4.5-10 4.5V3.5z" fill="currentColor"/>`;

    return `
      <div class="al-row${triggered ? " al-row-triggered" : ""}${!active ? " al-row-inactive" : ""}" data-alert-id="${esc(a.id)}">
        <div class="al-row-main">
          <div class="al-row-top">
            <div class="al-row-name">${esc((a.title || a.ean).slice(0, 50))}</div>
            ${statusChip}
          </div>
          <div class="al-row-ean text-mono">${esc(a.ean)}</div>
          <div class="al-row-meta">
            <span>Ziel: <strong style="color:var(--accent)">${fmtEur(a.target_price)}</strong></span>
            <span>Aktuell: ${priceCol}</span>
            <span class="text-muted">Geprüft: ${lastCheck}</span>
          </div>
          ${triggered && a.triggered_price ? `
            <div class="al-triggered-banner">
              🎯 Zielpreis erreicht! eBay-Preis war <strong>${fmtEur(a.triggered_price)}</strong>
              ${a.triggered_at ? `am ${fmtDate(a.triggered_at)}` : ""}
            </div>
          ` : ""}
          ${a.trigger_history?.length ? `
            <button class="al-history-toggle" data-hist-id="${esc(a.id)}">
              <span class="al-hist-arrow">▶</span> Verlauf (${a.trigger_history.length})
            </button>
            <div class="al-history-list" id="al-hist-${esc(a.id)}">
              ${[...a.trigger_history].reverse().map(h => `
                <div class="al-history-row">
                  <span class="text-muted">${fmtTime(h.ts)}</span>
                  <span style="color:var(--green);font-weight:600">${fmtEur(h.price)}</span>
                  ${a.target_price ? `<span class="text-muted" style="font-size:10px">−${fmtEur(Math.max(0, a.target_price - h.price))} unter Ziel</span>` : ""}
                </div>
              `).join("")}
            </div>
          ` : ""}
        </div>
        <div class="al-row-actions">
          <button class="btn btn-ghost btn-xs al-row-toggle" title="${toggleTitle}">
            <svg width="11" height="11" viewBox="0 0 16 16" fill="none">${toggleIcon}</svg>
          </button>
          ${triggered ? `<button class="btn btn-ghost btn-xs al-row-reset" title="Zurücksetzen">↺</button>` : ""}
          <button class="btn btn-ghost btn-xs al-row-del" title="Löschen">
            <svg width="11" height="11" viewBox="0 0 16 16" fill="none">
              <path d="M2 4h12M6 4V2h4v2M5 7v5M11 7v5M3 4l1 9h8l1-9" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </button>
        </div>
      </div>
    `;
  }

  function renderStats() {
    const statsCard = _el?.querySelector("#alStats");
    const statsBody = _el?.querySelector("#alStatsBody");
    if (!statsCard || !statsBody) return;

    const total     = _alerts.length;
    const active    = _alerts.filter(a => a.active && !a.triggered).length;
    const triggered = _alerts.filter(a => a.triggered).length;
    const paused    = _alerts.filter(a => !a.active).length;
    const checks    = _alerts.reduce((s, a) => s + (a.check_count || 0), 0);

    if (!total) { statsCard.style.display = "none"; return; }
    statsCard.style.display = "";

    statsBody.innerHTML = `
      <div class="al-stat"><span class="al-stat-v">${total}</span><span class="al-stat-l">Gesamt</span></div>
      <div class="al-stat"><span class="al-stat-v" style="color:var(--green)">${active}</span><span class="al-stat-l">Aktiv</span></div>
      <div class="al-stat"><span class="al-stat-v" style="color:var(--accent)">${triggered}</span><span class="al-stat-l">Ausgelöst</span></div>
      <div class="al-stat"><span class="al-stat-v" style="color:var(--text-muted)">${paused}</span><span class="al-stat-l">Pausiert</span></div>
      <div class="al-stat"><span class="al-stat-v">${checks}</span><span class="al-stat-l">Prüfungen</span></div>
    `;
  }

  // ── Bind UI events ─────────────────────────────────────────────────────────
  function bindEvents() {
    // Add alert
    _el?.querySelector("#alAdd")?.addEventListener("click", async () => {
      const ean    = _el.querySelector("#alEan")?.value.trim();
      const target = parseFloat(_el.querySelector("#alTarget")?.value);
      const title  = _el.querySelector("#alTitle")?.value.trim();

      if (!ean || !/^\d{8,14}$/.test(ean)) {
        Toast.error("Ungültige EAN", "Bitte eine gültige EAN/GTIN (8–14 Ziffern) eingeben.");
        return;
      }
      if (isNaN(target) || target <= 0) {
        Toast.error("Ungültiger Zielpreis", "Bitte einen gültigen Preis (> 0) eingeben.");
        return;
      }

      const addBtn = _el.querySelector("#alAdd");
      addBtn.disabled = true;
      addBtn.textContent = "Wird hinzugefügt…";

      _alerts = await Storage.addAlert({ ean, target_price: target, title: title || null });
      renderList();
      renderStats();

      // Reset form
      _el.querySelector("#alEan").value  = "";
      _el.querySelector("#alTarget").value = "";
      _el.querySelector("#alTitle").value = "";
      addBtn.disabled = false;
      addBtn.innerHTML = `
        <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
          <path d="M8 2v12M2 8h12" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
        </svg>
        Alarm hinzufügen
      `;

      Toast.success("Alarm gespeichert", `Preisalarm für EAN ${ean} (Ziel: ${fmtEur(target)}) aktiv.`);
    });

    // "Jetzt prüfen" button
    _el?.querySelector("#alRefresh")?.addEventListener("click", async () => {
      const btn = _el.querySelector("#alRefresh");
      btn.disabled = true;
      btn.innerHTML = `<span style="font-size:10px">Prüfe…</span>`;
      await runAlertChecks();
      _alerts = await Storage.listAlerts();
      renderList();
      renderStats();
      btn.disabled = false;
      btn.innerHTML = `
        <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
          <path d="M13.5 8A5.5 5.5 0 1 1 8 2.5c1.8 0 3.4.86 4.4 2.2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
          <path d="M13.5 2.5v3h-3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        Jetzt prüfen
      `;
    });
  }

  // ── Utility ────────────────────────────────────────────────────────────────
  function esc(s) {
    return String(s ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  }
  function fmtEur(val) {
    if (val == null || isNaN(val)) return "—";
    return new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(val);
  }
  function fmtDate(iso) {
    if (!iso) return "—";
    return new Intl.DateTimeFormat("de-DE", { day: "2-digit", month: "2-digit", year: "2-digit" }).format(new Date(iso));
  }
  function fmtTime(iso) {
    if (!iso) return "—";
    return new Intl.DateTimeFormat("de-DE", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" }).format(new Date(iso));
  }

  return { mount, unmount };
})();

// ── Background Alert Checker ────────────────────────────────────────────────
// Called by app.js timer every 15 min (and on "Jetzt prüfen")
async function runAlertChecks() {
  // Guard: prevent concurrent runs (e.g. timer fires while previous check still running)
  if (window._alertCheckRunning) return;
  window._alertCheckRunning = true;

  let alerts;
  try { alerts = await Storage.listAlerts(); } catch { window._alertCheckRunning = false; return; }

  const activeAlerts = alerts.filter(a => a.active && !a.triggered);
  if (!activeAlerts.length) { window._alertCheckRunning = false; return; }

  const base = App?.backendBase || "http://127.0.0.1:9000";
  let newlyTriggered = 0;

  try {
  for (const alert of activeAlerts) {
    try {
      const res = await fetch(`${base}/flipcheck`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ean: alert.ean, ek: 0, mode: "mid" }),
      });
      if (!res.ok) continue;

      const data = await res.json();

      // Find current market price — prefer sell_price_median, then sell_price_avg, then browse
      const currentPrice = data.sell_price_median ?? data.sell_price_avg ?? data.browse_price ?? null;

      // Build patch
      const patch = {
        id:           alert.id,
        last_checked: new Date().toISOString(),
        last_price:   currentPrice,
      };

      if (currentPrice != null && currentPrice <= alert.target_price) {
        patch.triggered       = true;
        patch.triggered_at    = new Date().toISOString();
        patch.triggered_price = currentPrice;
        newlyTriggered++;

        // Desktop notification
        const notifTitle = "🎯 Preisalarm ausgelöst!";
        const notifBody  = `${alert.title || alert.ean}: eBay-Preis ${new Intl.NumberFormat("de-DE",{style:"currency",currency:"EUR"}).format(currentPrice)} ≤ Ziel ${new Intl.NumberFormat("de-DE",{style:"currency",currency:"EUR"}).format(alert.target_price)}`;
        try { await window.fc.notify(notifTitle, notifBody); } catch {}

        Toast.success("Preisalarm!", `${alert.title || alert.ean}: ${new Intl.NumberFormat("de-DE",{style:"currency",currency:"EUR"}).format(currentPrice)}`);
      }

      await Storage.updateAlert(patch);
    } catch {
      // Skip failed checks silently
    }
  }
  } finally {
    window._alertCheckRunning = false;
  }

  if (newlyTriggered > 0) {
    // Re-render if alerts view is currently active (guard: only if _el still mounted)
    if (App?.currentView === "alerts" && AlertsView && document.querySelector("#view-root > div")) {
      const container = document.querySelector("#view-root > div");
      AlertsView.mount(container);
    }
  }
}
