/* Flipcheck v2 — Onboarding Wizard */
const OnboardingWizard = (() => {
  let _resolve = null;
  let _step    = 1;
  let _draft   = {
    vat_mode:       "no_vat",
    ek_mode:        "gross",
    flipcheck_mode: "mid",
  };

  const TOTAL_STEPS = 4;

  // ── Public ──────────────────────────────────────────────────────────────
  function show() {
    return new Promise(resolve => {
      _resolve = resolve;
      _step    = 1;
      _draft   = { vat_mode: "no_vat", ek_mode: "gross", flipcheck_mode: "mid" };
      const root = document.getElementById("wizard-root");
      if (!root) { resolve(null); return; }
      root.style.display = "flex";
      renderStep(root);
    });
  }

  // ── Renderer ─────────────────────────────────────────────────────────────
  function renderStep(root) {
    root.innerHTML = `
      <div class="wz-card">
        ${buildProgress()}
        <div class="wz-body" id="wzBody">
          ${buildStepHTML(_step)}
        </div>
        <div class="wz-actions" id="wzActions">
          ${buildActions(_step)}
        </div>
      </div>
    `;
    attachStepEvents(root);
  }

  function buildProgress() {
    const dots = Array.from({ length: TOTAL_STEPS }, (_, i) => {
      const active  = i + 1 === _step;
      const done    = i + 1 < _step;
      return `<div class="wz-dot ${active ? "wz-dot-active" : done ? "wz-dot-done" : ""}"></div>`;
    }).join('<div class="wz-dot-line"></div>');
    return `<div class="wz-progress">${dots}</div>`;
  }

  function buildStepHTML(step) {
    switch (step) {
      case 1: return buildWelcome();
      case 2: return buildTaxStep();
      case 3: return buildModeStep();
      case 4: return buildDoneStep();
      default: return "";
    }
  }

  function buildActions(step) {
    const back = step > 1
      ? `<button class="btn btn-ghost btn-sm" id="wzBack">← Zurück</button>`
      : `<div></div>`;

    const next = step < TOTAL_STEPS
      ? `<button class="btn btn-primary" id="wzNext">Weiter →</button>`
      : "";  // Step 4 has its own buttons

    return `${back}${next}`;
  }

  // ── Step 1: Willkommen ───────────────────────────────────────────────────
  function buildWelcome() {
    return `
      <div class="wz-welcome">
        <div class="wz-logo">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none">
            <path d="M13 2L4.5 13.5H11L10 22L19.5 10.5H13L13 2Z"
              fill="#6366F1" stroke="#6366F1" stroke-width="1"
              stroke-linejoin="round"/>
          </svg>
          <span class="wz-logo-text">Flipcheck</span>
        </div>

        <h1 class="wz-title">eBay-Reselling profitabel machen</h1>
        <p class="wz-subtitle">
          Scanne Produkte, berechne echten Gewinn und finde die besten Deals —
          alles an einem Ort.
        </p>

        <div class="wz-features">
          <div class="wz-feature">
            <div class="wz-feature-icon">📊</div>
            <div>
              <div class="wz-feature-title">Live Marktdaten</div>
              <div class="wz-feature-sub">eBay-Preise, Verkaufszahlen & Konkurrenz in Echtzeit</div>
            </div>
          </div>
          <div class="wz-feature">
            <div class="wz-feature-icon">💰</div>
            <div>
              <div class="wz-feature-title">Profit-Kalkulator</div>
              <div class="wz-feature-sub">BUY/HOLD/SKIP mit exakten Margen & ROI-Werten</div>
            </div>
          </div>
          <div class="wz-feature">
            <div class="wz-feature-icon">🏆</div>
            <div>
              <div class="wz-feature-title">Verkaufs-Tracking</div>
              <div class="wz-feature-sub">Echte Gewinne, Plattform-Fees & monatliche Auswertung</div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // ── Step 2: MwSt & EK-Modus ──────────────────────────────────────────────
  function buildTaxStep() {
    const v = _draft;
    return `
      <div class="wz-section">
        <div class="wz-step-header">
          <div class="wz-step-num">Schritt 2 von ${TOTAL_STEPS}</div>
          <h2 class="wz-step-title">Steuer & Einkaufspreise</h2>
          <p class="wz-step-sub">Diese Einstellungen bestimmen, wie Flipcheck deinen Gewinn berechnet.</p>
        </div>

        <div class="wz-form">
          <div class="wz-form-group">
            <label class="wz-label">Bist du umsatzsteuerpflichtig?</label>
            <p class="wz-hint">Kleinunternehmer wählen "Ohne MwSt".</p>
            <div class="seg" id="segVat">
              <button class="seg-btn ${v.vat_mode === "no_vat" ? "active" : ""}" data-val="no_vat">
                Ohne MwSt
              </button>
              <button class="seg-btn ${v.vat_mode === "ust_19" ? "active" : ""}" data-val="ust_19">
                Mit USt 19%
              </button>
            </div>
          </div>

          <div class="wz-form-group">
            <label class="wz-label">Wie gibst du deinen Einkaufspreis ein?</label>
            <p class="wz-hint">Kaufst du z.B. bei Amazon ein, ist der Preis meistens Brutto.</p>
            <div class="seg" id="segEk">
              <button class="seg-btn ${v.ek_mode === "gross" ? "active" : ""}" data-val="gross">
                Brutto (inkl. MwSt)
              </button>
              <button class="seg-btn ${v.ek_mode === "net" ? "active" : ""}" data-val="net">
                Netto (exkl. MwSt)
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // ── Step 3: Flipcheck-Modus ───────────────────────────────────────────────
  function buildModeStep() {
    const sel = _draft.flipcheck_mode;
    const modes = [
      {
        id:    "low",
        label: "Konservativ",
        icon:  "🛡️",
        min_margin: "≥ 25%",
        min_roi:    "≥ 30%",
        desc:  "Nur sichere Flips mit hoher Marge. Weniger Deals, aber mehr Sicherheit.",
      },
      {
        id:    "mid",
        label: "Ausgewogen",
        icon:  "⚖️",
        min_margin: "≥ 15%",
        min_roi:    "≥ 20%",
        desc:  "Gute Balance zwischen Deals und Sicherheit. Ideal für Einsteiger.",
        badge: "EMPFOHLEN",
      },
      {
        id:    "high",
        label: "Aggressiv",
        icon:  "🚀",
        min_margin: "≥ 10%",
        min_roi:    "≥ 10%",
        desc:  "Mehr Deals, aber auch mehr Risiko. Für erfahrene Reseller.",
      },
    ];

    return `
      <div class="wz-section">
        <div class="wz-step-header">
          <div class="wz-step-num">Schritt 3 von ${TOTAL_STEPS}</div>
          <h2 class="wz-step-title">Flipcheck-Modus</h2>
          <p class="wz-step-sub">Wähle, wie streng Flipcheck BUY-Empfehlungen ausspricht.</p>
        </div>

        <div class="wz-mode-grid">
          ${modes.map(m => `
            <div class="wz-mode-card ${sel === m.id ? "selected" : ""}" data-mode="${m.id}">
              ${m.badge ? `<span class="wz-mode-badge">${m.badge}</span>` : ""}
              <div class="wz-mode-icon">${m.icon}</div>
              <div class="wz-mode-label">${m.label}</div>
              <div class="wz-mode-metrics">
                <span>Margin ${m.min_margin}</span>
                <span>ROI ${m.min_roi}</span>
              </div>
              <div class="wz-mode-desc">${m.desc}</div>
            </div>
          `).join("")}
        </div>
      </div>
    `;
  }

  // ── Step 4: Bereit! ───────────────────────────────────────────────────────
  function buildDoneStep() {
    return `
      <div class="wz-done">
        <div class="wz-check-wrap">
          <svg class="wz-check-svg" viewBox="0 0 52 52" fill="none">
            <circle class="wz-check-circle" cx="26" cy="26" r="25" stroke="#6366F1" stroke-width="2"/>
            <path class="wz-check-tick" d="M14 26l9 9 15-15" stroke="#6366F1" stroke-width="2.5"
              stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>

        <h2 class="wz-done-title">Alles eingerichtet!</h2>
        <p class="wz-done-sub">
          Deine Einstellungen wurden gespeichert. Du kannst jetzt loslegen.
        </p>

        <div class="wz-done-ean">
          <label class="wz-label" style="margin-bottom:8px">Erstes Produkt direkt scannen (optional):</label>
          <div class="row gap-8">
            <input class="input" id="wzFirstEan" placeholder="EAN eingeben, z.B. 5901234123457"
              style="flex:1;font-family:var(--font-mono, monospace)" maxlength="14">
            <button class="btn btn-secondary" id="wzScanFirst">Scannen →</button>
          </div>
        </div>

        <div class="wz-done-actions">
          <button class="btn btn-primary" id="wzFinish">Zum Dashboard →</button>
        </div>
      </div>
    `;
  }

  // ── Events ────────────────────────────────────────────────────────────────
  function attachStepEvents(root) {
    // Back
    root.querySelector("#wzBack")?.addEventListener("click", () => {
      _step--;
      renderStep(root);
    });

    // Next
    root.querySelector("#wzNext")?.addEventListener("click", () => {
      _step++;
      renderStep(root);
    });

    // Step 1: "Los geht's" button inside body — swap Next button
    // (Step 1 uses the normal "Weiter →" next button)

    // Step 2: segmented controls
    root.querySelectorAll("#segVat .seg-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        root.querySelectorAll("#segVat .seg-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        _draft.vat_mode = btn.dataset.val;
      });
    });
    root.querySelectorAll("#segEk .seg-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        root.querySelectorAll("#segEk .seg-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        _draft.ek_mode = btn.dataset.val;
      });
    });

    // Step 3: mode cards
    root.querySelectorAll(".wz-mode-card").forEach(card => {
      card.addEventListener("click", () => {
        root.querySelectorAll(".wz-mode-card").forEach(c => c.classList.remove("selected"));
        card.classList.add("selected");
        _draft.flipcheck_mode = card.dataset.mode;
      });
    });

    // Step 4: Finish → Dashboard
    root.querySelector("#wzFinish")?.addEventListener("click", async () => {
      await saveAndClose(null, root);
    });

    // Step 4: Scan first product
    root.querySelector("#wzScanFirst")?.addEventListener("click", async () => {
      const ean = root.querySelector("#wzFirstEan")?.value.trim();
      if (ean && /^\d{8,14}$/.test(ean)) {
        await saveAndClose(ean, root);
      } else {
        root.querySelector("#wzFirstEan")?.focus();
        if (typeof Toast !== "undefined") Toast.warning("Ungültige EAN", "8–14 Ziffern erforderlich.");
      }
    });

    // Enter key in EAN input
    root.querySelector("#wzFirstEan")?.addEventListener("keydown", e => {
      if (e.key === "Enter") root.querySelector("#wzScanFirst")?.click();
    });
  }

  async function saveAndClose(firstEan, root) {
    try {
      await Storage.saveSettings({
        onboarding_done: true,
        tax: {
          vat_mode: _draft.vat_mode,
          ek_mode:  _draft.ek_mode,
        },
        defaults: {
          market:         "ebay",
          flipcheck_mode: _draft.flipcheck_mode,
        },
      });
    } catch (e) {
      console.error("[Onboarding] saveSettings failed:", e);
    }

    root.style.display = "none";
    root.innerHTML = "";
    if (_resolve) { _resolve(firstEan || null); _resolve = null; }
  }

  return { show };
})();
