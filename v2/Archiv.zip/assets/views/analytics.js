/* Flipcheck v2 — Analytics View */
const AnalyticsView = (() => {
  let charts = {};
  let _period = "weekly"; // "weekly" | "monthly"

  const CHART_DEFAULTS = {
    color: "#6366F1",
    green: "#10B981",
    yellow: "#F59E0B",
    red: "#EF4444",
    grid: "rgba(30,30,46,0.8)",
    text: "#475569",
    font: "Inter, -apple-system, sans-serif",
  };

  function destroyCharts() {
    Object.values(charts).forEach(c => { try { c.destroy(); } catch {} });
    charts = {};
  }

  async function mount(container) {
    container.innerHTML = renderSkeleton();

    let items = [];
    try { items = await Storage.listInventory(); } catch {}

    const stats = Storage.calcInventoryAnalytics(items);
    const soldItems = items.filter(i => i.status === "SOLD" && i.sell_price && i.ek);
    container.innerHTML = renderView(stats, items.length);
    initCharts(stats, container);
    attachPeriodToggle(stats, soldItems, container);
  }

  function unmount() { destroyCharts(); _period = "weekly"; }

  function renderSkeleton() {
    return `
      <div class="page-header">
        <div class="page-header-left">
          <div class="skeleton" style="width:160px;height:24px;margin-bottom:8px"></div>
          <div class="skeleton" style="width:240px;height:14px"></div>
        </div>
      </div>
      <div class="grid-kpi" style="margin-bottom:20px">
        ${[1,2,3,4].map(() => `<div class="kpi-card"><div class="skeleton" style="height:70px"></div></div>`).join("")}
      </div>
      <div class="grid-2">
        <div class="panel"><div class="skeleton" style="height:220px"></div></div>
        <div class="panel"><div class="skeleton" style="height:220px"></div></div>
      </div>
    `;
  }

  function renderView(s, totalCount) {
    const roiColor = s.avgRoi >= 20 ? "text-green" : s.avgRoi >= 10 ? "text-yellow" : "text-secondary";
    const profitColor = s.totalProfit > 0 ? "text-green" : s.totalProfit < 0 ? "text-red" : "text-secondary";

    return `
      <div class="page-header">
        <div class="page-header-left">
          <h1>Analytics</h1>
          <p>${s.soldCount} verkauft · ${s.activeCount} aktiv · ${totalCount} gesamt</p>
        </div>
        <div class="page-header-actions">
          <button class="btn btn-secondary btn-sm" id="btnRefreshAnalytics">
            <svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M2 8a6 6 0 1 0 1.5-3.9M2 2v4h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            Aktualisieren
          </button>
        </div>
      </div>

      <!-- KPI Cards -->
      <div class="grid-kpi mb-16">
        <div class="kpi-card">
          <div class="kpi-label">Gesamtprofit</div>
          <div class="kpi-value ${profitColor}">${fmtEur(s.totalProfit)}</div>
          <div class="kpi-meta">
            <span>${s.soldCount} Verkäufe</span>
          </div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Ø ROI</div>
          <div class="kpi-value ${roiColor}">${s.avgRoi > 0 ? "+" : ""}${s.avgRoi.toFixed(1)}%</div>
          <div class="kpi-meta">
            <span class="${roiColor} font-semibold">${s.avgRoi >= 20 ? "Exzellent" : s.avgRoi >= 10 ? "Gut" : s.soldCount > 0 ? "Ausbaufähig" : "Keine Daten"}</span>
          </div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Aktives Kapital</div>
          <div class="kpi-value">${fmtEur(s.activeCash)}</div>
          <div class="kpi-meta">
            <span>${s.activeCount} Artikel gebunden</span>
          </div>
        </div>
        <div class="kpi-card">
          <div class="kpi-label">Ø Days to Cash</div>
          <div class="kpi-value">${s.avgDaysToCash > 0 ? fmtDays(s.avgDaysToCash) : "—"}</div>
          <div class="kpi-meta">
            <span>Einkauf → Verkauf</span>
          </div>
        </div>
      </div>

      <!-- Charts Row -->
      <div class="grid-2 mb-16">
        <div class="panel">
          <div class="row-between mb-8">
            <h3 class="panel-title" style="margin-bottom:0">Profit-Kurve</h3>
            <div class="analytics-period-toggle">
              <button class="seg-btn ${_period==="weekly"?"active":""}" data-period="weekly">Wöchentlich</button>
              <button class="seg-btn ${_period==="monthly"?"active":""}" data-period="monthly">Monatlich</button>
            </div>
          </div>
          ${s.weeklyProfit.every(w => w.profit === 0) ? `
            <div class="empty-state" style="padding:20px">
              <p class="empty-sub">Noch keine verkauften Artikel mit Verkaufspreis gespeichert.</p>
            </div>
          ` : `
            <div class="chart-container">
              <canvas id="chartProfit" height="200"></canvas>
            </div>
          `}
        </div>
        <div class="panel">
          <div class="row-between mb-8">
            <h3 class="panel-title" style="margin-bottom:0">Portfolio-Split</h3>
            <span class="badge badge-gray">${totalCount} Artikel</span>
          </div>
          ${totalCount === 0 ? `
            <div class="empty-state" style="padding:20px"><p class="empty-sub">Keine Inventory-Daten vorhanden.</p></div>
          ` : `
            <div class="chart-container" style="display:flex;align-items:center;justify-content:center">
              <canvas id="chartMarket" height="200" style="max-width:200px"></canvas>
            </div>
          `}
        </div>
      </div>

      <!-- Best / Worst Flips -->
      <div class="grid-2">
        <div class="panel">
          <h3 class="panel-title">Beste Flips</h3>
          ${renderFlipTable(s.bestFlips, "best")}
        </div>
        <div class="panel">
          <h3 class="panel-title">Schlechteste Flips</h3>
          ${renderFlipTable(s.worstFlips, "worst")}
        </div>
      </div>

      <!-- Cashflow Panel -->
      <div class="panel mt-16">
        <div class="row-between mb-8">
          <h3 class="panel-title" style="margin-bottom:0">Cashflow-Übersicht</h3>
          <span class="badge badge-gray">Verkaufte Artikel</span>
        </div>
        <div class="grid-3">
          <div>
            <div class="kpi-label">Gesamtumsatz</div>
            <div style="font-size:18px;font-weight:800;color:var(--text-primary);font-variant-numeric:tabular-nums">${fmtEur(s.totalRevenue)}</div>
          </div>
          <div>
            <div class="kpi-label">Gesamteinkauf</div>
            <div style="font-size:18px;font-weight:800;color:var(--text-primary);font-variant-numeric:tabular-nums">${fmtEur(s.totalCost)}</div>
          </div>
          <div>
            <div class="kpi-label">Nettoprofit</div>
            <div style="font-size:18px;font-weight:800;${s.totalProfit >= 0 ? "color:var(--green)" : "color:var(--red)"};font-variant-numeric:tabular-nums">${fmtEur(s.totalProfit)}</div>
          </div>
        </div>
      </div>
    `;
  }

  function renderFlipTable(flips, type) {
    if (!flips.length) {
      return `<div class="empty-state" style="padding:20px"><p class="empty-sub">Noch keine verkauften Artikel.</p></div>`;
    }
    return `
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th>Artikel</th>
              <th class="col-right">EK</th>
              <th class="col-right">VK</th>
              <th class="col-right">Profit</th>
              <th class="col-right">ROI</th>
            </tr>
          </thead>
          <tbody>
            ${flips.map(f => `
              <tr>
                <td style="max-width:160px">
                  <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(f.title || f.ean)}">${esc(f.title || f.ean || "—")}</div>
                  ${f.ean ? `<div class="text-xs text-muted">${esc(f.ean)}</div>` : ""}
                </td>
                <td class="col-right col-num">${fmtEur(f.ek)}</td>
                <td class="col-right col-num">${fmtEur(f.sell_price)}</td>
                <td class="col-right col-num ${f.profit >= 0 ? "text-green" : "text-red"}">${fmtEur(f.profit)}</td>
                <td class="col-right"><span class="badge ${f.roi >= 15 ? "badge-green" : f.roi >= 0 ? "badge-yellow" : "badge-red"}">${fmtPct(f.roi)}</span></td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    `;
  }

  function initCharts(s, container) {
    const C = CHART_DEFAULTS;

    Chart.defaults.font.family = C.font;
    Chart.defaults.color = C.text;

    // ── Profit Line Chart ──────────────────────────────────────────────
    const ctxProfit = document.getElementById("chartProfit");
    if (ctxProfit && s.weeklyProfit.length) {
      charts.profit = new Chart(ctxProfit, {
        type: "line",
        data: {
          labels: s.weeklyProfit.map(w => w.label),
          datasets: [{
            label: "Profit",
            data: s.weeklyProfit.map(w => w.profit),
            borderColor: C.color,
            backgroundColor: "rgba(99,102,241,0.08)",
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            pointRadius: 3,
            pointHoverRadius: 5,
            pointBackgroundColor: C.color,
            pointBorderColor: "transparent",
          }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: true,
          interaction: { intersect: false, mode: "index" },
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: "#16161F",
              borderColor: "#2E2E42",
              borderWidth: 1,
              titleColor: "#F1F5F9",
              bodyColor: "#94A3B8",
              callbacks: {
                label: ctx => ` ${fmtEur(ctx.parsed.y)}`,
              },
            },
          },
          scales: {
            x: {
              grid: { color: "rgba(30,30,46,0.6)", drawBorder: false },
              ticks: { font: { size: 10 }, color: C.text },
            },
            y: {
              grid: { color: "rgba(30,30,46,0.6)", drawBorder: false },
              ticks: {
                font: { size: 10 },
                color: C.text,
                callback: v => fmtEur(v),
              },
            },
          },
        },
      });
    }

    // ── Market Donut Chart ─────────────────────────────────────────────
    const ctxMarket = document.getElementById("chartMarket");
    if (ctxMarket) {
      const labels = Object.keys(s.marketSplit);
      const values = Object.values(s.marketSplit);
      const COLORS = ["#6366F1","#10B981","#F59E0B","#EF4444","#3B82F6","#8B5CF6"];

      charts.market = new Chart(ctxMarket, {
        type: "doughnut",
        data: {
          labels,
          datasets: [{
            data: values,
            backgroundColor: labels.map((_, i) => COLORS[i % COLORS.length]),
            borderColor: "#111118",
            borderWidth: 3,
            hoverBorderWidth: 3,
          }],
        },
        options: {
          responsive: true,
          cutout: "70%",
          plugins: {
            legend: {
              position: "right",
              labels: { font: { size: 11 }, padding: 12, color: "#94A3B8", boxWidth: 10, boxHeight: 10 },
            },
            tooltip: {
              backgroundColor: "#16161F",
              borderColor: "#2E2E42",
              borderWidth: 1,
              titleColor: "#F1F5F9",
              bodyColor: "#94A3B8",
              callbacks: {
                label: ctx => ` ${ctx.label}: ${ctx.parsed} Artikel`,
              },
            },
          },
        },
      });
    }

    // Refresh button — use the captured container reference
    container.querySelector("#btnRefreshAnalytics")?.addEventListener("click", async () => {
      destroyCharts();
      await mount(container);
    });
  }

  // ── Monthly profit calculation ─────────────────────────────────────────────
  function calcMonthlyProfit(soldItems) {
    const months = [];
    const now = new Date();
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push({
        key:    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`,
        label:  d.toLocaleDateString("de-DE", { month: "short", year: "2-digit" }),
      });
    }
    const map = {};
    for (const m of months) map[m.key] = 0;
    for (const item of soldItems) {
      if (!item.sold_at) continue;
      const d   = new Date(item.sold_at || item.updated_at);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      if (map[key] !== undefined) map[key] += (item.sell_price || 0) - (item.ek || 0);
    }
    return months.map(m => ({ label: m.label, profit: Math.round(map[m.key] * 100) / 100 }));
  }

  // ── Period toggle (weekly ↔ monthly) ─────────────────────────────────────
  function attachPeriodToggle(stats, soldItems, container) {
    container.querySelectorAll(".analytics-period-toggle .seg-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        _period = btn.dataset.period;
        container.querySelectorAll(".analytics-period-toggle .seg-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        const profitData = _period === "monthly"
          ? calcMonthlyProfit(soldItems)
          : stats.weeklyProfit;

        if (charts.profit) {
          charts.profit.data.labels              = profitData.map(w => w.label);
          charts.profit.data.datasets[0].data    = profitData.map(w => w.profit);
          charts.profit.update("active");
        }
      });
    });
  }

  return { mount, unmount };
})();
