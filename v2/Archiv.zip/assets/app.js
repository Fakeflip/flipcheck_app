/* Flipcheck v2 — App Router & API Client */

// ─── Global state ─────────────────────────────────────────────────────────────
const App = {
  token: null,
  backendBase: null,
  settings: {},
  currentView: null,
  viewInstances: {},
  _navId: 0, // Navigation counter to cancel stale async mounts
};

// ─── Utility ──────────────────────────────────────────────────────────────────
function esc(str) {
  return String(str ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

function fmtEur(val) {
  if (val == null || isNaN(val)) return "—";
  return new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(val);
}

function fmtPct(val) {
  if (val == null || !isFinite(val) || isNaN(val)) return "—";
  return `${val >= 0 ? "+" : ""}${val.toFixed(1)}%`;
}

function fmtDate(iso) {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("de-DE", { day: "2-digit", month: "2-digit", year: "2-digit" }).format(new Date(iso));
}

function fmtDays(n) {
  if (n == null || isNaN(n)) return "—";
  return `${Math.round(n)}d`;
}

// ─── API Client ───────────────────────────────────────────────────────────────
const API = {
  async call(path, { method = "GET", body = null } = {}) {
    const base = App.backendBase || "http://127.0.0.1:9000";
    const headers = { "Content-Type": "application/json" };
    if (App.token) headers["Authorization"] = `Bearer ${App.token}`;

    const opts = { method, headers };
    if (body) opts.body = JSON.stringify(body);

    const res = await fetch(`${base}${path}`, opts);
    let data = null;
    try { data = await res.json(); } catch (e) { console.warn("[API] JSON parse error on", path, e); }
    return { ok: res.ok, status: res.status, data };
  },

  async flipcheck(ean, ek, mode = "mid", extra = {}) {
    return this.call("/flipcheck", { method: "POST", body: { ean, ek, mode, ...extra } });
  },

  async health() {
    return this.call("/health");
  },

  async dealscan(budget, minMargin, minRoi, limit = 20) {
    return this.call("/deals/scan", {
      method: "POST",
      body: { budget, min_margin: minMargin, min_roi: minRoi, limit },
    });
  },

  async sellerListings(sellerId, limit = 50, q = "") {
    const p = new URLSearchParams({ seller_id: sellerId, limit });
    if (q && q.trim()) p.set("q", q.trim());
    return this.call(`/seller/listings?${p}`);
  },

  async eanCompetition(ean, limit = 50) {
    return this.call(`/ean/competition?ean=${encodeURIComponent(ean)}&limit=${limit}`);
  },

  async compare(ean, ek = 0) {
    const p = new URLSearchParams({ ean, ek });
    return this.call(`/compare?${p}`);
  },

  async verify() {
    return this.call("/auth/verify");
  },
};

// ─── Router ───────────────────────────────────────────────────────────────────
const VIEW_TITLES = {
  analytics:   "Analytics",
  flipcheck:   "Flipcheck",
  batch:       "Batch Flipcheck",
  inventory:   "Inventory",
  history:     "Preishistorie",
  dealscan:    "Deal-Scanner",
  competition: "Konkurrenz-Monitor",
  alerts:      "Preisalarm",
  marketplace: "Marktplatz-Vergleich",
  sales:       "Verkäufe",
  settings:    "Einstellungen",
};

const VIEW_MAP = {
  analytics:   typeof AnalyticsView   !== "undefined" ? AnalyticsView   : null,
  flipcheck:   typeof FlipcheckView   !== "undefined" ? FlipcheckView   : null,
  batch:       typeof BatchView       !== "undefined" ? BatchView       : null,
  inventory:   typeof InventoryView   !== "undefined" ? InventoryView   : null,
  history:     typeof HistoryView     !== "undefined" ? HistoryView     : null,
  dealscan:    typeof DealScanView    !== "undefined" ? DealScanView    : null,
  competition: typeof CompetitionView !== "undefined" ? CompetitionView : null,
  alerts:      typeof AlertsView      !== "undefined" ? AlertsView      : null,
  marketplace: typeof MarketplaceView !== "undefined" ? MarketplaceView : null,
  sales:       typeof SalesView       !== "undefined" ? SalesView       : null,
  settings:    typeof SettingsView    !== "undefined" ? SettingsView    : null,
};

function navigateTo(viewKey) {
  const viewRoot = document.getElementById("view-root");
  const pageTitle = document.getElementById("page-title");
  if (!viewRoot) return;

  // Increment nav ID — async mounts can check if they're still current
  const navId = ++App._navId;

  // Update nav active state
  document.querySelectorAll(".nav-item[data-view]").forEach(el => {
    el.classList.toggle("active", el.dataset.view === viewKey);
  });

  // Update page title
  if (pageTitle) pageTitle.textContent = VIEW_TITLES[viewKey] || viewKey;

  // Unmount current view
  if (App.currentView && App.viewInstances[App.currentView]?.unmount) {
    try { App.viewInstances[App.currentView].unmount(); } catch {}
  }

  // Mount new view
  viewRoot.innerHTML = "";
  const viewContainer = document.createElement("div");
  viewContainer.className = "view-enter";
  viewRoot.appendChild(viewContainer);

  App.currentView = viewKey;

  const ViewClass = VIEW_MAP[viewKey];
  if (ViewClass?.mount) {
    try {
      App.viewInstances[viewKey] = ViewClass;
      // Pass navId so async views can bail if navigation changed
      ViewClass.mount(viewContainer, navId);
    } catch (e) {
      console.error(`[Router] Failed to mount view "${viewKey}":`, e);
      if (navId === App._navId) {
        viewContainer.innerHTML = `<div class="empty-state"><p class="text-red">Fehler beim Laden der View: ${esc(e.message)}</p></div>`;
      }
    }
  } else {
    viewContainer.innerHTML = `
      <div class="empty-state">
        <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
        <p class="empty-title">View nicht gefunden</p>
        <p class="empty-sub">"${esc(viewKey)}" ist noch nicht implementiert.</p>
      </div>
    `;
  }

  window.location.hash = viewKey;
}

// ─── Backend Status ───────────────────────────────────────────────────────────
async function updateBackendStatus() {
  const pill = document.getElementById("backendStatus");
  if (!pill) return;
  try {
    const { ok } = await API.health();
    pill.className = `status-pill ${ok ? "ok" : "err"}`;
    pill.querySelector(".status-text").textContent = ok ? "Online" : "Offline";
  } catch {
    pill.className = "status-pill err";
    pill.querySelector(".status-text").textContent = "Offline";
  }
}

// ─── Auth ─────────────────────────────────────────────────────────────────────
async function checkAuth() {
  const gate = document.getElementById("auth-gate");
  const appEl = document.getElementById("app");

  // In dev/local mode: skip auth gate entirely
  let authRequired = true;
  try { authRequired = await window.fc.requireAuth(); } catch {}

  if (!authRequired) {
    gate.style.display = "none";
    appEl.style.display = "flex";
    return true;
  }

  let token = null;
  try { token = await window.fc.getToken(); } catch {}

  if (!token) {
    gate.style.display = "flex";
    appEl.style.display = "none";
    return false;
  }

  App.token = token;
  gate.style.display = "none";
  appEl.style.display = "flex";
  return true;
}

function showGate(message) {
  const gate = document.getElementById("auth-gate");
  const appEl = document.getElementById("app");
  const hint = document.getElementById("gateHint");
  App.token = null;
  gate.style.display = "flex";
  appEl.style.display = "none";
  if (hint && message) hint.textContent = message;
}

// ─── Boot ─────────────────────────────────────────────────────────────────────
async function boot() {
  Modal.init();

  // Setup logout button
  document.getElementById("btnLogout")?.addEventListener("click", async () => {
    const ok = await Modal.confirm("Ausloggen", "Möchtest du dich wirklich ausloggen?", { confirmLabel: "Ausloggen", danger: true });
    if (ok) {
      try { await window.fc.logout(); } catch {}
      showGate("Erfolgreich ausgeloggt.");
    }
  });

  // Login button
  document.getElementById("btnLogin")?.addEventListener("click", () => {
    try { window.fc.login(); } catch {}
    const hint = document.getElementById("gateHint");
    if (hint) hint.textContent = "Browser geöffnet — bitte anmelden…";
  });

  // Listen for deep-link auth token
  try {
    window.fc.onAuthToken(async (token) => {
      App.token = token;
      const gate = document.getElementById("auth-gate");
      const appEl = document.getElementById("app");
      gate.style.display = "none";
      appEl.style.display = "flex";
      Toast.success("Angemeldet", "Willkommen bei Flipcheck!");
      initApp();
    });
  } catch {}

  // Nav click handlers
  document.querySelectorAll(".nav-item[data-view]").forEach(el => {
    el.addEventListener("click", (e) => {
      e.preventDefault();
      navigateTo(el.dataset.view);
    });
  });

  // Tag platform on <html> for platform-specific CSS
  try {
    const plat = await window.fc.platform();
    if (plat) document.documentElement.dataset.platform = plat;
  } catch {}

  // Load backend base
  try { App.backendBase = await window.fc.backendBase(); } catch {}
  try { App.settings = await Storage.getSettings(); } catch {}

  // Load version
  try {
    const v = await window.fc.version();
    const el = document.getElementById("appVersion");
    if (el && v) el.textContent = `v${v}`;
  } catch {}

  // Check auth
  const authed = await checkAuth();
  if (authed) initApp();
}

async function initApp() {
  // ── Onboarding: show wizard on first run ──────────────────────────────────
  const settings = await Storage.getSettings();
  if (!settings.onboarding_done && typeof OnboardingWizard !== "undefined") {
    const firstEan = await OnboardingWizard.show();
    // Wizard saved settings (incl. onboarding_done: true) before resolving
    if (firstEan) {
      // User entered an EAN on the done screen → go straight to Flipcheck
      navigateTo("flipcheck");
      // Pre-fill the EAN input after the view has mounted (short delay)
      setTimeout(() => {
        const inp = document.querySelector("#fcEan");
        if (inp) { inp.value = firstEan; inp.dispatchEvent(new Event("input")); }
      }, 150);
    } else {
      navigateTo("analytics");
    }
  } else {
    // Normal start: restore last view from hash or default to analytics
    const hash    = window.location.hash.replace("#", "");
    const initial = VIEW_MAP[hash] ? hash : "analytics";
    navigateTo(initial);
  }

  // Start backend status polling
  updateBackendStatus();
  setInterval(updateBackendStatus, 15000);

  // Start price alert background timer (every 15 minutes)
  if (typeof runAlertChecks === "function") {
    // Initial check after 30s (give backend time to start)
    setTimeout(() => runAlertChecks(), 30_000);
    setInterval(() => runAlertChecks(), 15 * 60 * 1000);
  }
}

// ─── Start ────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", boot);
